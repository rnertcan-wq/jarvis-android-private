# Jarvis APK — GitHub Actions hazırlık paketi

Bu depo **özel (Private)** olmalıdır. İçindeki orijinal APK'de EVREN API anahtarı gömülüdür. Depoyu Public yapmayın, APK'yi herkese açık issue/PR veya artifact bağlantılarında paylaşmayın.

## Bu paket ne yapar?

GitHub Actions üzerinde:
1. Java 17 kurar.
2. Android SDK build-tools, `apksigner` ve `zipalign` kurar.
3. Apktool ile APK'yi Smali + kaynak/manifest biçiminde açar.
4. JADX ile DEX'i Java benzeri kaynak görünüme dönüştürür.
5. Anahtar değerlerini veya kaynak satırlarını yazdırmadan bir inceleme özeti üretir.
6. APKTool decode/rebuild doğrulamasını dener. Bu aşamada **hiçbir hata düzeltmesi uygulanmaz**.
7. Sonuçları 3 gün saklanan GitHub Actions artifact'i olarak yükler.

Bu ilk aşama kaynakları çıkarıp inceleme için hazırlar. Tek başına düzeltilmiş APK üretmez.

## GitHub'da çalıştırma

1. https://github.com/new adresini aç.
2. Yeni depo adı olarak `jarvis-android-private` yaz.
3. **Private** seçeneğini işaretle. Public seçme.
4. Depoyu oluştur.
5. Bu ZIP'i bilgisayarına indirip aç.
6. ZIP'in içindeki tüm dosya ve klasörleri GitHub deposuna yükle. Özellikle `.github/workflows/jarvis-apk-inspect.yml` dosyasının gizli `.github/workflows` klasöründe olduğundan emin ol.
7. `input/Jarvis-Android-v0.9.0-Kisisel.apk` dosyasının depoda bulunduğunu kontrol et.
8. GitHub deposunda **Actions** sekmesine gir.
9. Soldan **Jarvis APK - decompile and rebuild check** iş akışını seç.
10. **Run workflow** düğmesine bas.
11. İşlem bitince sayfanın altındaki **Artifacts** bölümünden `jarvis-v0.9.0-decompile-analysis` dosyasını indir.
12. İndirdiğin ZIP'i bu sohbete yükle. Smali/manifest ve Java decompile çıktıları üzerinden gerçek düzeltmeleri hazırlayabiliriz.

## Güvenlik

- APK'deki mevcut EVREN anahtarı bu paket içinde değiştirilmedi.
- Anahtar APK'den çıkarılabilir; bu nedenle GitHub deposu ve Actions artifact'i private erişimle korunmalıdır.
- GitHub Actions loglarına anahtar yazdırılmaz.
- Bu depo için herkese açık GitHub Pages/Release oluşturmayın.
- Orijinal APK'yi ayrıca güvenli bir yerde saklayın.

## İmza notu

Orijinal APK'nin özel imzalama anahtarı APK dosyasının içinde bulunmaz. Yeniden derlenen APK farklı bir test anahtarıyla imzalanırsa mevcut uygulamanın üstüne güncelleme olarak kurulamayabilir; önceki uygulamayı kaldırıp yenisini kurmanız gerekebilir. Bu paketin ilk aşaması APK'yi imzalamaz ve telefona kurulum yapmaz.
