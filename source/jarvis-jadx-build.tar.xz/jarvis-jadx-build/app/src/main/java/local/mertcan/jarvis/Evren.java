package local.mertcan.jarvis;

import android.content.Context;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.net.SocketTimeoutException;
import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
final class Evren {
    private static final String BASE = "https://evren-llmapi.ssyz.org.tr/v1/";
    static volatile String key = "";
    private static final MediaType JSON = MediaType.parse("application/json");

    Evren() {
    }

    static String error(Exception exc) {
        String message = exc.getMessage() == null ? "" : exc.getMessage();
        if (message.equals("EVREN HTTP 401") || message.equals("EVREN HTTP 403")) {
            return "EVREN anahtarı veya proje erişimi reddedildi.";
        }
        if (message.equals("EVREN HTTP 429")) {
            return "EVREN kotası dolu veya istek sınırı aşıldı.";
        }
        if ((exc instanceof SocketTimeoutException) || (exc instanceof InterruptedIOException)) {
            return "EVREN yanıtı zaman aşımına uğradı.";
        }
        return message.equals("EVREN boş yanıt verdi.") ? message : "EVREN yanıt vermedi; bağlantıyı ve servis durumunu kontrol et.";
    }

    private static Request post(String str, String str2, JSONObject jSONObject) {
        return new Request.Builder().url(BASE + str).header("Authorization", "Bearer " + str2).post(RequestBody.create(JSON, jSONObject.toString())).build();
    }

    static String answer(String str, String str2) throws Exception {
        Response responseExecute = Cloud.HTTP.newCall(post("chat/completions", str2, Cloud.object("model", "deepseek-v4.1-flash", "max_tokens", 220, "messages", new JSONArray().put(Cloud.object("role", "system", "content", "Kısa ve doğal Türkçe konuş. Telefon işlemi yaptığını veya güncel kaynağa baktığını iddia etme; bu mod yalnızca sohbet.")).put(Cloud.object("role", "user", "content", str))))).execute();
        try {
            if (!responseExecute.isSuccessful() || responseExecute.body() == null) {
                throw new IOException("EVREN HTTP " + responseExecute.code());
            }
            String strTrim = new JSONObject(responseExecute.body().string()).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content").trim();
            if (strTrim.isEmpty()) {
                throw new IOException("EVREN boş yanıt verdi.");
            }
            String strSubstring = strTrim.substring(0, Math.min(1200, strTrim.length()));
            if (responseExecute != null) {
                responseExecute.close();
            }
            return strSubstring;
        } catch (Throwable th) {
            if (responseExecute != null) {
                try {
                    responseExecute.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    /* JADX WARN: Code duplicated, block: B:70:0x00aa A[EXC_TOP_SPLITTER, SYNTHETIC] */
    static File speech(Context context, String str, String str2) throws Exception {
        File fileCreateTempFile = File.createTempFile("jarvis-tts-", ".wav", context.getCacheDir());
        boolean z = false;
        try {
            Response responseExecute = Cloud.HTTP.newCall(post("audio/speech", str2, Cloud.object("model", "voxcpm2", "input", str.substring(0, Math.min(1200, str.length())), "voice", "default", "response_format", "wav"))).execute();
            try {
                if (!responseExecute.isSuccessful() || responseExecute.body() == null) {
                    throw new IOException("EVREN ses HTTP " + responseExecute.code());
                }
                InputStream inputStreamByteStream = responseExecute.body().byteStream();
                try {
                    FileOutputStream fileOutputStream = new FileOutputStream(fileCreateTempFile);
                    try {
                        byte[] bArr = new byte[8192];
                        int i = 0;
                        while (true) {
                            int i2 = inputStreamByteStream.read(bArr);
                            if (i2 == -1) {
                                fileOutputStream.close();
                                if (inputStreamByteStream != null) {
                                    inputStreamByteStream.close();
                                }
                                if (fileCreateTempFile.length() < 44) {
                                    throw new IOException("Ses dosyası geçersiz.");
                                }
                                if (responseExecute != null) {
                                    try {
                                        responseExecute.close();
                                    } catch (Throwable th) {
                                        th = th;
                                        z = true;
                                    }
                                }
                                return fileCreateTempFile;
                            }
                            i += i2;
                            if (i > 8388608) {
                                throw new IOException("Ses çok büyük");
                            }
                            fileOutputStream.write(bArr, 0, i2);
                            if (inputStreamByteStream != null) {
                                try {
                                    inputStreamByteStream.close();
                                } catch (Throwable th2) {
                                    th.addSuppressed(th2);
                                }
                            }
                            throw th;
                        }
                    } catch (Throwable th3) {
                        try {
                            fileOutputStream.close();
                        } catch (Throwable th4) {
                            th3.addSuppressed(th4);
                        }
                        throw th3;
                    }
                } catch (Throwable th5) {
                    if (inputStreamByteStream != null) {
                        inputStreamByteStream.close();
                    }
                    throw th5;
                }
            } catch (Throwable th6) {
                if (responseExecute != null) {
                    try {
                        responseExecute.close();
                    } catch (Throwable th7) {
                        th6.addSuppressed(th7);
                    }
                }
                throw th6;
            }
        } catch (Throwable th8) {
            th = th8;
        }
        th = th8;
        if (!z) {
            fileCreateTempFile.delete();
        }
        throw th;
    }
}
