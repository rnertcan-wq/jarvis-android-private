package local.mertcan.jarvis;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/* JADX INFO: loaded from: classes.dex */
final class Secrets {
    private static final String ALIAS = "jarvis-api-keys-v1";

    Secrets() {
    }

    private static synchronized SecretKey key(boolean z) throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        if (keyStore.containsAlias(ALIAS)) {
            return (SecretKey) keyStore.getKey(ALIAS, null);
        }
        if (!z) {
            return null;
        }
        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES", "AndroidKeyStore");
        keyGenerator.init(new KeyGenParameterSpec.Builder(ALIAS, 3).setBlockModes("GCM").setEncryptionPaddings("NoPadding").build());
        return keyGenerator.generateKey();
    }

    static void save(Context context, String str, String str2) throws Exception {
        if (str2.isEmpty()) {
            Main.prefs(context).edit().remove("secret." + str).putBoolean("bootstrapUsed." + str, true).apply();
            return;
        }
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(1, key(true));
        cipher.updateAAD(str.getBytes(StandardCharsets.UTF_8));
        Main.prefs(context).edit().putString("secret." + str, Base64.encodeToString(cipher.getIV(), 2) + ":" + Base64.encodeToString(cipher.doFinal(str2.getBytes(StandardCharsets.UTF_8)), 2)).putBoolean("bootstrapUsed." + str, true).apply();
    }

    /* JADX WARN: Code duplicated, block: B:45:0x009c A[EXC_TOP_SPLITTER, SYNTHETIC] */
    static String loadPersonal(Context context, String str) {
        String strLoad = load(context, str);
        if (!strLoad.isEmpty() || Main.prefs(context).getBoolean("bootstrapUsed." + str, false)) {
            return strLoad;
        }
        try {
            InputStream inputStreamOpen = context.getAssets().open(str + ".bootstrap");
            try {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                try {
                    byte[] bArr = new byte[256];
                    while (true) {
                        int i = inputStreamOpen.read(bArr);
                        if (i == -1) {
                            String strTrim = new String(byteArrayOutputStream.toByteArray(), StandardCharsets.UTF_8).trim();
                            if (!strTrim.isEmpty()) {
                                save(context, str, strTrim);
                            }
                            byteArrayOutputStream.close();
                            if (inputStreamOpen != null) {
                                inputStreamOpen.close();
                            }
                            return strTrim;
                        }
                        if (byteArrayOutputStream.size() + i > 4096) {
                            byteArrayOutputStream.close();
                            if (inputStreamOpen != null) {
                                inputStreamOpen.close();
                            }
                            return "";
                        }
                        byteArrayOutputStream.write(bArr, 0, i);
                        if (inputStreamOpen != null) {
                            try {
                                inputStreamOpen.close();
                            } catch (Throwable th) {
                                th.addSuppressed(th);
                            }
                        }
                        throw th;
                    }
                } catch (Throwable th2) {
                    try {
                        byteArrayOutputStream.close();
                    } catch (Throwable th3) {
                        th2.addSuppressed(th3);
                    }
                    throw th2;
                }
            } catch (Throwable th4) {
                if (inputStreamOpen != null) {
                    inputStreamOpen.close();
                }
                throw th4;
            }
        } catch (Exception e) {
            return "";
        }
    }

    static String load(Context context, String str) {
        try {
            String string = Main.prefs(context).getString("secret." + str, "");
            if (string.isEmpty()) {
                return "";
            }
            String[] strArrSplit = string.split(":");
            SecretKey secretKeyKey = key(false);
            if (secretKeyKey != null && strArrSplit.length == 2) {
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(2, secretKeyKey, new GCMParameterSpec(128, Base64.decode(strArrSplit[0], 0)));
                cipher.updateAAD(str.getBytes(StandardCharsets.UTF_8));
                return new String(cipher.doFinal(Base64.decode(strArrSplit[1], 0)), StandardCharsets.UTF_8);
            }
            return "";
        } catch (Exception e) {
            return "";
        }
    }
}
