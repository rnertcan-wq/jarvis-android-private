# Keep reflective Android service/activity entry points intact.
-keep class local.mertcan.jarvis.** { *; }
