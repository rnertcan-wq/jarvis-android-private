package local.mertcan.jarvis;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.widget.EditText;
import android.widget.Toast;
import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

                                          
final class GeminiAccess {
    private static volatile boolean foreground;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static WeakReference<Main> screen = new WeakReference<>(null);

    GeminiAccess() {
    }

    static void open(final Main main) {
        screen = new WeakReference<>(main);
        if (!Cloud.key.isEmpty()) {
            main.confirmGemini();
            return;
        }
        final EditText editText = new EditText(main);
        editText.setSingleLine(true);
        editText.setInputType(129);
        editText.setHint("Gemini API anahtarı");
        new AlertDialog.Builder(main).setTitle("Gemini Live bağlantısı").setMessage("Google AI Studio’dan aldığın, Live API erişimi olan anahtarı gir.").setView(editText).setPositiveButton("Kaydet ve devam et", new DialogInterface.OnClickListener() {                                                                           
            @Override                                                   
            public final void onClick(DialogInterface dialogInterface, int i) {
                GeminiAccess.lambda$open$0(editText, main, dialogInterface, i);
            }
        }).setNegativeButton("Vazgeç", (DialogInterface.OnClickListener) null).show();
    }

    static                 void lambda$open$0(EditText editText, Main main, DialogInterface dialogInterface, int i) {
        String strTrim = editText.getText().toString().trim();
        if (!strTrim.matches("[A-Za-z0-9_-]{20,128}")) {
            Toast.makeText(main, "Gemini anahtar biçimini kontrol et.", 1).show();
            return;
        }
        try {
            Secrets.save(main, "gemini", strTrim);
            Cloud.key = strTrim;
            main.confirmGemini();
        } catch (Exception unused) {
            Toast.makeText(main, "Gemini anahtarı kaydedilemedi.", 1).show();
        }
    }

    static String liveUrl() {
        return "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=" + Uri.encode(Cloud.key);
    }

    static String setup() throws JSONException {
        JSONArray jSONArrayPut = new JSONArray()
                .put(function("sleep_live", "Sessiz ol, Live modu bitir veya sohbeti bitir komutunda beklemeye dön.", null))
                .put(function("map_view", "Sürüş ekranındaki haritayı büyütmek için size=expand, küçültmek için size=shrink gönder.", "size"))
                .put(function("camera_view", "Sürüş ekranındaki küçük kamera önizlemesini aç veya kapat. visible=true ya da false gönder.", "visible"))
                .put(function("navigate", "Google Maps'te sürüş rotası başlat. destination alanına hedef adresi veya yeri yaz.", "destination"))
                .put(function("stop_music", "Müziği duraklat veya YouTube Music'i kapat.", null))
                .put(function("device_clock", "Telefonun gerçek yerel saat ve tarihini oku.", null))
                .put(function("phone_call", "Rehberde kişiyi bul, telefon numarasını sesli bildir ve yalnızca kullanıcı EVET dedikten sonra ara.", "target"))
                .put(function("research", "Google'da web araması ve güncel bilgi doğrulaması yap.", "query"))
                .put(function("rates", "Güncel döviz kurlarını oku.", null))
                .put(function("news", "Güncel haber başlıklarını oku.", null));
        JSONObject jSONObjectFunction = function("music", "Müzik aç, duraklat veya devam ettir.", "action");
        jSONObjectFunction.getJSONObject("parameters").getJSONObject("properties").put("query", new JSONObject().put("type", "STRING"));
        jSONArrayPut.put(jSONObjectFunction);
        return new JSONObject().put("setup", new JSONObject().put("model", "models/gemini-3.8-live").put("generationConfig", new JSONObject().put("responseModalities", new JSONArray().put("AUDIO"))).put("inputAudioTranscription", new JSONObject()).put("outputAudioTranscription", new JSONObject()).put("tools", new JSONArray().put(new JSONObject().put("functionDeclarations", jSONArrayPut))).put("systemInstruction", new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text", "Türkçe konuş. Saat ve tarih için device_clock, internet için research, telefon için phone_call, müziği durdurmak için stop_music kullan. Telefon aramasında numarayı kullanıcıya sesli bildir ve EVET yanıtı gelmeden asla arama yapma. Kamera için camera_view, Google Maps rotası için navigate, harita boyutu için map_view kullan. YouTube Music açmak için music ve action=youtube_music kullan. Sessiz ol veya Live modu bitir denirse sleep_live çağır. Araç sonucu olmadan yetki veya başarı hakkında tahmin yürütme."))))).toString();
    }

    static String startupFailure(Throwable th) {
        return "Gemini Live başlatılamadı · " + th.getClass().getSimpleName();
    }

    private static JSONObject function(String str, String str2, String str3) throws JSONException {
        JSONObject jSONObjectPut = new JSONObject().put("name", str).put("description", str2);
        return str3 == null ? jSONObjectPut : jSONObjectPut.put("parameters", new JSONObject().put("type", "OBJECT").put("properties", new JSONObject().put(str3, new JSONObject().put("type", "STRING"))).put("required", new JSONArray().put(str3)));
    }

    static String dispatchDeviceTool(Context context, String str, JSONObject jSONObject) {
        final String strTrim;
        if ("camera_view".equals(str)) {
            JSONObject args = jSONObject.optJSONObject("args");
            boolean visible = args != null && "true".equalsIgnoreCase(args.optString("visible"));
            return DriveDashboard.cameraCommand(visible);
        }
        if ("navigate".equals(str)) {
            JSONObject args = jSONObject.optJSONObject("args");
            String destination = args == null ? "" : args.optString("destination", "").trim();
            if (destination.isEmpty()) return "Navigasyon hedefini söyle.";
            return MapsNavigator.open(context, destination);
        }
        if ("map_view".equals(str)) {
            JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("args");
            strTrim = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optString("size") : "";
            if ("expand".equals(strTrim)) {
                return DriveDashboard.mapCommand(true);
            }
            return "shrink".equals(strTrim) ? DriveDashboard.mapCommand(false) : "Harita boyutu için büyüt veya küçült de.";
        }
        if ("stop_music".equals(str)) {
            AudioManager audioManager = (AudioManager) context.getSystemService(AudioManager.class);
            if (audioManager == null) {
                return "Android medya denetimi kullanılamıyor.";
            }
            try {
                audioManager.dispatchMediaKeyEvent(new KeyEvent(0, 127));
                audioManager.dispatchMediaKeyEvent(new KeyEvent(1, 127));
                return "Durdurma komutu Android'in etkin medya oynatıcısına gönderildi.";
            } catch (RuntimeException unused) {
                return "Medya durdurma komutu gönderilemedi.";
            }
        }
        if ("device_clock".equals(str)) {
            return new SimpleDateFormat("d MMMM yyyy EEEE, saat HH:mm", Locale.forLanguageTag("tr-TR")).format(new Date());
        }
        if (!"phone_call".equals(str)) return null;
        JSONObject args = jSONObject.optJSONObject("args");
        String target = args == null ? "" : args.optString("target", "").trim();
        if (target.isEmpty() || target.length() > 100) return "Aranacak adı veya numarayı sor.";
        String response = LiveRepair.local(context, "ara " + target);
        return response == null ? "Aranacak kişiyi eşleştiremedim." : response;
    }

    static void foreground(Main main, boolean z) {
        foreground = z;
        if (z) {
            screen = new WeakReference<>(main);
        }
    }

    static String closeMessage(int i, String str, boolean z) {
        String str2 = z ? "konuşma sırasında" : "bağlantı kurulurken";
        String str3 = "";
        if (str == null) {
            str = "";
        }
        String str4 = Cloud.key;
        if (str4 != null && !str4.isEmpty()) {
            str = str.replace(str4, "[gizlendi]");
        }
        String strTrim = str.replaceAll("[\\p{Cntrl}]+", " ").trim();
        if (strTrim.length() > 180) {
            strTrim = strTrim.substring(0, 180);
        }
        StringBuilder sb = new StringBuilder("Gemini Live ");
        sb.append(str2);
        sb.append(" kapandı (");
        sb.append(i);
        sb.append(").");
        if (!strTrim.isEmpty()) {
            str3 = " " + strTrim;
        }
        sb.append(str3);
        return sb.toString();
    }

    static void reportStatus(final String str) {
        MAIN.post(new Runnable() {                                                                           
            @Override                      
            public final void run() {
                GeminiAccess.lambda$reportStatus$3(str);
            }
        });
    }

    static                 void lambda$reportStatus$3(String str) {
        Main main = screen.get();
        if (main != null && !main.isDestroyed()) {
            main.showLiveStatus(str);
        }
        DriveDashboard.liveStatus(str);
    }

    static void report(final Context context, final String str) {
        MAIN.post(new Runnable() {                                                                           
            @Override                      
            public final void run() {
                GeminiAccess.lambda$report$4(str, context);
            }
        });
    }

    static                 void lambda$report$4(String str, Context context) {
        Main main = screen.get();
        if (main != null && !main.isDestroyed()) {
            main.showLiveStatus(str);
        }
        Toast.makeText(context, str, 1).show();
    }
}
