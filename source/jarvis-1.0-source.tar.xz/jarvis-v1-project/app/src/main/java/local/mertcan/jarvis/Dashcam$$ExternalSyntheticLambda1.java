package local.mertcan.jarvis;

                                                  
                                         
public final                 class Dashcam$$ExternalSyntheticLambda1 implements Runnable {
    public final                 Dashcam f$0;

    public                 Dashcam$$ExternalSyntheticLambda1(Dashcam dashcam) {
        this.f$0 = dashcam;
    }

    @Override                      
    public final void run() {
        this.f$0.startSegment();
    }
}
