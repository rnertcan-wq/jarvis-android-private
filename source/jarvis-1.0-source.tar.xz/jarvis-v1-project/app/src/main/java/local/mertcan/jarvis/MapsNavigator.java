package local.mertcan.jarvis;

import android.content.Context;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.net.Uri;

                                                                           
final class MapsNavigator {
    private MapsNavigator() { }

    static String openHome(Context context) {
        String home = Main.prefs(context).getString("home", "").trim();
        if (home.isEmpty()) return "Ev adresi kayıtlı değil. Jarvis ayarlarından ev adresini kaydet.";
        return open(context, home);
    }

    static String open(Context context, String destination) {
        try {
            Uri uri;
            String target = destination == null ? "" : destination.trim();
            if (target.isEmpty()) {
                uri = Uri.parse("https://www.google.com/maps");
            } else {
                uri = Uri.parse("https://www.google.com/maps/dir/?api=1")
                        .buildUpon()
                        .appendQueryParameter("destination", target)
                        .appendQueryParameter("travelmode", "driving")
                        .appendQueryParameter("dir_action", "navigate")
                        .build();
            }
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.setPackage("com.google.android.apps.maps");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                context.startActivity(intent);
                return target.isEmpty() ? "Google Maps açılıyor." : "Google Maps'te " + target + " rotası açılıyor.";
            } catch (ActivityNotFoundException noMaps) {
                intent.setPackage(null);
                context.startActivity(intent);
                return "Google Maps uygulaması bulunamadı. Haritayı tarayıcıda açıyorum.";
            }
        } catch (RuntimeException e) {
            return "Navigasyon başlatılamadı. Konum ve Google Maps izinlerini kontrol et.";
        }
    }
}
