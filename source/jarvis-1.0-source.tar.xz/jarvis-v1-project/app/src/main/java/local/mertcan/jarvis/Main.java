package local.mertcan.jarvis;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Insets;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.hardware.camera2.CameraManager;
import android.location.LocationManager;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.speech.RecognitionListener;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.KeyEvent;
import android.view.OrientationEventListener;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

                                         
public final class Main extends Activity implements RecognitionListener {
    private AudioManager audio;
    private EditText command;
    private int evrenGeneration;
    private MediaPlayer evrenPlayer;
    private AudioFocusRequest focus;
    private boolean pendingHome;
    private boolean pendingTelegram;
    private boolean ready;
    private boolean listenAfterSpeech;
    private boolean recordDual;
    private boolean recordFront;
    private OrientationEventListener recordingOrientation;
    private LinearLayout row;
    private SpeechRecognizer speech;
    private TextView status;
    private LinearLayout ui;
    private static Main visible;
    private TextToSpeech voice;
    private boolean wide;
    static final Locale TR = new Locale("tr", "TR");
    private String telegramRecipient = "";
    private int physicalDegrees = -1;
    private final BroadcastReceiver recordStatus = new BroadcastReceiver() {                                           
        @Override                                     
        public void onReceive(Context context, Intent intent) {
            String stringExtra = intent.getStringExtra("text");
            if (stringExtra != null) {
                Main.this.status.setText(stringExtra);
            }
        }
    };

                                                           
    public void confirmLive() {
        LiveRepair.select(this);
    }

    void releaseMicForEvrenTalk() {
        stopEvren();
        SpeechRecognizer speechRecognizer = this.speech;
        if (speechRecognizer != null) {
            speechRecognizer.cancel();
        }
        TextToSpeech textToSpeech = this.voice;
        if (textToSpeech != null) {
            textToSpeech.stop();
        }
    }

    void showLiveStatus(String str) {
        this.status.setText(str);
    }

    void startEvrenLive() {
        if (GeminiLive.active || VoiceDrive.active) {
            this.status.setText("Önce açık olan ses oturumunu durdur.");
        } else if (LiveRepair.request(this)) {
            DriveCamera.yieldMicrophone(this);
            stopEvren();
            enableHandsFree();
        }
    }

    static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences("jarvis", 0);
    }

    static String launchYouTubeMusic(final String str) {
        final Main main = visible;
        if (main == null) {
            return "YouTube Music oturumu açık değil. Park hâlindeyken uygulamayı bir kez aç.";
        }
        if (main.driving()) {
            return "Sürüşte yeni ekran açılmadı. Park hâlindeyken YouTube Music'i aç.";
        }
        if (Actions.youtubeLaunchIntent(main) == null) {
            return "YouTube Music kurulu değil.";
        }
        main.runOnUiThread(new Runnable() {                                                                   
            @Override                      
            public final void run() {
                Main.lambda$launchYouTubeMusic$0(this.f$0, str);
            }
        });
        return "YouTube Music'e oynatma isteği gönderildi.";
    }

    static                 void lambda$launchYouTubeMusic$0(Main main, String str) {
        if (visible != main || main.driving()) {
            return;
        }
        try {
            main.startActivity(Actions.youtubePlayIntent(str));
        } catch (ActivityNotFoundException e) {
            if (!str.isEmpty()) {
                main.open(new Intent("android.intent.action.VIEW", Uri.parse("https://music.youtube.com/search?q=" + Uri.encode(str))));
            } else {
                main.open(Actions.youtubeLaunchIntent(main));
            }
        }
    }

    static boolean dispatchTelegram(String str) {
        return visible != null && visible.telegram(str);
    }

    static boolean awaitingTelegram() {
        return visible != null && visible.pendingTelegram;
    }

    @Override                        
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Cloud.key = Secrets.loadPersonal(this, "gemini");
        Evren.key = Secrets.loadPersonal(this, "evren");
        this.recordingOrientation = new OrientationEventListener(this) {                                           
            @Override                                         
            public void onOrientationChanged(int i) {
                if (i != -1) {
                    Main.this.physicalDegrees = (((i + 45) / 90) * 90) % 360;
                }
            }
        };
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().getDecorView().setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {                                                                    
                @Override                                                 
                public final WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
                    return Main.lambda$onCreate$1(view, windowInsets);
                }
            });
        }
        this.audio = (AudioManager) getSystemService(AudioManager.class);
        final AudioAttributes audioAttributesBuild = new AudioAttributes.Builder().setUsage(16).setContentType(1).build();
        this.focus = new AudioFocusRequest.Builder(3).setAudioAttributes(audioAttributesBuild).build();
        this.voice = new TextToSpeech(this, new TextToSpeech.OnInitListener() {                                                                    
            @Override                                                  
            public final void onInit(int i) {
                this.f$0.m77lambda$onCreate$2$localmertcanjarvisMain(audioAttributesBuild, i);
            }
        });
        this.wide = getResources().getConfiguration().orientation == 2;
        if (bundle != null) {
            this.pendingHome = bundle.getBoolean("homePending");
            this.pendingTelegram = bundle.getBoolean("telegramPending");
            this.telegramRecipient = bundle.getString("telegramRecipient", "");
        }
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        this.ui = new LinearLayout(this);
        this.ui.setOrientation(1);
        GradientDrawable pageBackground = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF07111F, 0xFF0B1728, 0xFF101D31});
        this.ui.setBackground(pageBackground);
        int iDp = dp(this.wide ? 14 : 18);
        this.ui.setPadding(iDp, iDp, iDp, iDp);
        scrollView.addView(this.ui);
        setContentView(scrollView);
        TextView eyebrow = new TextView(this);
        eyebrow.setText("PERSONAL AI  ·  VOICE & DRIVE SYSTEM");
        eyebrow.setTextColor(0xFF78A8E8);
        eyebrow.setTextSize(10.5f);
        eyebrow.setLetterSpacing(0.12f);
        eyebrow.setTypeface(android.graphics.Typeface.create("sans-serif-medium", 0));
        this.ui.addView(eyebrow);

        TextView textView = new TextView(this);
        textView.setText("JARVIS");
        textView.setTextColor(0xFFF1F6FF);
        textView.setTextSize(32.0f);
        textView.setLetterSpacing(0.16f);
        textView.setTypeface(android.graphics.Typeface.create("sans-serif-medium", 1));
        this.ui.addView(textView);

        FrameLayout orbPanel = new FrameLayout(this);
        orbPanel.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(this.wide ? 128 : 164)));
        GradientDrawable orbPanelBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF102845, 0xFF0B1728});
        orbPanelBg.setCornerRadius(dp(22));
        orbPanelBg.setStroke(dp(1), 0x553F8CDA);
        orbPanel.setBackground(orbPanelBg);
        TextView orb = new TextView(this);
        orb.setText("◉");
        orb.setGravity(17);
        orb.setTextSize(this.wide ? 54 : 66);
        orb.setTextColor(0xFF73C5FF);
        orb.setShadowLayer(dp(18), 0, 0, 0xFF268DFF);
        orbPanel.addView(orb, new FrameLayout.LayoutParams(-1, -1));
        TextView orbCaption = new TextView(this);
        orbCaption.setText("HEY JARVIS  ·  SESLİ ASİSTAN HAZIR");
        orbCaption.setGravity(17);
        orbCaption.setTextColor(0xFFB6C9E2);
        orbCaption.setTextSize(10);
        orbCaption.setLetterSpacing(0.08f);
        FrameLayout.LayoutParams orbCaptionLp = new FrameLayout.LayoutParams(-1, dp(26), 80);
        orbCaptionLp.gravity = 80;
        orbPanel.addView(orbCaption, orbCaptionLp);
        this.ui.addView(orbPanel);

        this.status = new TextView(this);
        this.status.setText("Sistem hazır · Türkçe sesli asistan");
        this.status.setTextColor(0xFFE0ECFA);
        this.status.setTextSize(13.5f);
        this.status.setPadding(dp(13), dp(12), dp(13), dp(12));
        GradientDrawable statusBg = new GradientDrawable();
        statusBg.setColor(0xFF14253A);
        statusBg.setCornerRadius(dp(14));
        statusBg.setStroke(dp(1), 0x334B91D1);
        this.status.setBackground(statusBg);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1, -2);
        statusLp.topMargin = dp(10);
        this.ui.addView(this.status, statusLp);
        this.command = new EditText(this);
        this.command.setId(13260033);
        this.command.setHint(this.pendingTelegram ? "Mesajını yaz veya söyle…" : "Komut yaz…");
        this.command.setSingleLine(true);
        this.command.setTextColor(0xFFF3F7FF);
        this.command.setHintTextColor(0xFF8FA6C2);
        GradientDrawable commandBg = new GradientDrawable();
        commandBg.setColor(0xFF111F32);
        commandBg.setCornerRadius(dp(14));
        commandBg.setStroke(dp(1), 0x553E78B5);
        this.command.setBackground(commandBg);
        this.command.setPadding(dp(14), dp(10), dp(14), dp(10));
        LinearLayout.LayoutParams commandLp = new LinearLayout.LayoutParams(-1, -2);
        commandLp.topMargin = dp(12);
        this.ui.addView(this.command, commandLp);
        section("Hızlı işlemler");
        button("Konuş", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.listen();
            }
        });
        button("Komutu çalıştır", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.m78lambda$onCreate$3$localmertcanjarvisMain();
            }
        });
        button("Hey Jarvis dinleyicisini aç", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.enableHandsFree();
            }
        });
        button("Hey Jarvis dinleyicisini kapat", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.m79lambda$onCreate$4$localmertcanjarvisMain();
            }
        });
        button("Sohbet ve komut geçmişi", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.history();
            }
        });
        section("Ses ve ajanlar");
        button("Sağlayıcı: " + (usingGemini() ? "Gemini" : "EVREN"), new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.provider();
            }
        });
        button("Gemini anahtarı", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.cloudKey();
            }
        });
        button("EVREN anahtarı", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.evrenKey();
            }
        });
        button("EVREN ile konuş", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.m80lambda$onCreate$5$localmertcanjarvisMain();
            }
        });
        button("Hey Jarvis · Dinlemeyi başlat", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.confirmLive();
            }
        });
        button("Eller serbest dinlemeyi kapat", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.m81lambda$onCreate$6$localmertcanjarvisMain();
            }
        });
        button("Google'da araştır", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.searchDialog();
            }
        });
        button("Telegram", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.openTelegram();
            }
        });
        button("Telegram kişi takma adı", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.m82lambda$onCreate$7$localmertcanjarvisMain();
            }
        });
        section("Sürüş ve navigasyon");
        button("Sürüşü başlat", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.drive();
            }
        });
        button("Sürüşü bitir", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.endDrive();
            }
        });
        button("Aracın Bluetooth'unu seç", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.car();
            }
        });
        button("Ev adresini ayarla", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.m83lambda$onCreate$8$localmertcanjarvisMain();
            }
        });
        button("Eve git", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.home();
            }
        });
        button("Bildirim erişimi ayarları", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.m84lambda$onCreate$9$localmertcanjarvisMain();
            }
        });
        button("Arama izinleri", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.m69lambda$onCreate$10$localmertcanjarvisMain();
            }
        });
        section("Bilgi ve kayıt");
        button("Haber başlıklarını oku", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.m70lambda$onCreate$11$localmertcanjarvisMain();
            }
        });
        button("TCMB döviz kurlarını oku", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.m71lambda$onCreate$12$localmertcanjarvisMain();
            }
        });
        button("Sürüş kamerası", DriveCamera.panelAction(this));
        button("Kamera uyumluluğunu kontrol et", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.cameraCheck();
            }
        });
        button("Arka kamera + ses kaydını başlat", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.m72lambda$onCreate$13$localmertcanjarvisMain();
            }
        });
        button("Ön kamera + ses kaydını başlat", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.m73lambda$onCreate$14$localmertcanjarvisMain();
            }
        });
        button("Ön ve arka kamera + ses kaydını başlat", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.m74lambda$onCreate$15$localmertcanjarvisMain();
            }
        });
        button("Kayıt durdur", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.stopRecord();
            }
        });
        button("Kayıtları galeriye aktar", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.exportRecording();
            }
        });
        section("Araçlar");
        button("Termux'u aç", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.termux();
            }
        });
        button("GitHub'ı aç", new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.m75lambda$onCreate$16$localmertcanjarvisMain();
            }
        });
        IntentFilter intentFilter = new IntentFilter("local.mertcan.jarvis.RECORDING_STATUS");
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(this.recordStatus, intentFilter, 4);
        } else {
            registerReceiver(this.recordStatus, intentFilter);
        }
        Retention.schedule(this);
        new Thread(new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.m76lambda$onCreate$17$localmertcanjarvisMain();
            }
        }, "retention").start();
        fromIntent(getIntent());
    }

    static                 WindowInsets lambda$onCreate$1(View view, WindowInsets windowInsets) {
        Insets insets = windowInsets.getInsets(WindowInsets.Type.systemBars());
        view.setPadding(insets.left, insets.top, insets.right, insets.bottom);
        return windowInsets;
    }

                                                                                                           
                    void m77lambda$onCreate$2$localmertcanjarvisMain(AudioAttributes audioAttributes, int i) {
        if (i != 0 || this.voice == null) {
            return;
        }
        this.ready = this.voice.setLanguage(TR) >= 0;
        this.voice.setAudioAttributes(audioAttributes);
        this.voice.setOnUtteranceProgressListener(new UtteranceProgressListener() {                                           
            @Override                                                
            public void onStart(String str) {
            }

            @Override                                                
            public void onDone(String str) {
                Main.this.audio.abandonAudioFocusRequest(Main.this.focus);
                if (Main.this.listenAfterSpeech && !Main.this.isFinishing() && !Main.this.isDestroyed()) {
                    Main.this.listenAfterSpeech = false;
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override public void run() { if (!Main.this.isFinishing() && !Main.this.isDestroyed()) Main.this.listen(); }
                    }, 280L);
                }
            }

            @Override                                                
            public void onError(String str) {
                Main.this.audio.abandonAudioFocusRequest(Main.this.focus);
            }
        });
    }

                                                                                                           
                    void m78lambda$onCreate$3$localmertcanjarvisMain() {
        act(this.command.getText().toString());
    }

                                                                                                           
                    void m79lambda$onCreate$4$localmertcanjarvisMain() {
        LiveRepair.stop(this);
        stopService(new Intent(this, (Class<?>) VoiceDrive.class));
    }

                                                                                                           
                    void m80lambda$onCreate$5$localmertcanjarvisMain() {
        this.command.setText("EVREN ");
        this.command.requestFocus();
        this.command.setSelection(this.command.length());
        this.status.setText("Sorunu EVREN sözcüğünden sonra yaz veya söyle.");
    }

                                                                                                           
                    void m81lambda$onCreate$6$localmertcanjarvisMain() {
        LiveRepair.stop(this);
        stopService(new Intent(this, (Class<?>) GeminiLive.class));
    }

                                                                                                           
                    void m82lambda$onCreate$7$localmertcanjarvisMain() {
        editTelegramAlias("", "");
    }

                                                                                                           
                    void m84lambda$onCreate$9$localmertcanjarvisMain() {
        open(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
    }

                                                                                                            
                    void m69lambda$onCreate$10$localmertcanjarvisMain() {
        requestPermissions(new String[]{"android.permission.READ_CONTACTS", "android.permission.CALL_PHONE"}, 4);
    }

                                                                                                            
                    void m70lambda$onCreate$11$localmertcanjarvisMain() {
        brief(false);
    }

                                                                                                            
                    void m71lambda$onCreate$12$localmertcanjarvisMain() {
        brief(true);
    }

                                                                                                            
                    void m72lambda$onCreate$13$localmertcanjarvisMain() {
        record(false, false);
    }

                                                                                                            
                    void m73lambda$onCreate$14$localmertcanjarvisMain() {
        record(false, true);
    }

                                                                                                            
                    void m74lambda$onCreate$15$localmertcanjarvisMain() {
        record(true, false);
    }

                                                                                                            
                    void m75lambda$onCreate$16$localmertcanjarvisMain() {
        if (driving()) {
            return;
        }
        view("https://github.com/");
    }

                                                                                                            
                    void m76lambda$onCreate$17$localmertcanjarvisMain() {
        Retention.purge(this);
    }

    @Override                        
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        fromIntent(intent);
    }

    private void fromIntent(Intent intent) {
        if ("local.mertcan.jarvis.DRIVE".equals(intent.getAction())) {
            intent.setAction(null);
            drive();
            return;
        }
        if ("local.mertcan.jarvis.LIVE_START".equals(intent.getAction())) {
            intent.setAction(null);
            startLive();
        }
    }

    private int dp(int i) {
        return (int) ((i * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private void section(String str) {
        this.row = null;
        TextView textView = new TextView(this);
        textView.setText(str.toUpperCase(TR));
        textView.setTextColor(0xFF80B8F3);
        textView.setTextSize(11.5f);
        textView.setLetterSpacing(0.10f);
        textView.setTypeface(android.graphics.Typeface.create("sans-serif-medium", 0));
        textView.setPadding(dp(3), dp(16), 0, dp(5));
        this.ui.addView(textView);
    }

    private void button(String str, final Runnable runnable) {
        Button button = new Button(this);
        button.setText(str);
        button.setAllCaps(false);
        button.setOnClickListener(new View.OnClickListener() {                                                                    
            @Override                                     
            public final void onClick(View view) {
                runnable.run();
            }
        });
        button.setTextSize(13.0f);
        button.setTypeface(android.graphics.Typeface.create("sans-serif-medium", 0));
        button.setTextColor(0xFFEAF3FF);
        GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                str.equals("Konuş") ? new int[]{0xFF1C6DC1, 0xFF164B8D} : new int[]{0xFF1B2F49, 0xFF14243A});
        gradientDrawable.setCornerRadius(dp(14));
        gradientDrawable.setStroke(dp(1), str.equals("Konuş") ? 0xAA55B5FF : 0x554D78A7);
        button.setBackground(new RippleDrawable(ColorStateList.valueOf(0x557BBEFF), gradientDrawable, null));
        button.setPadding(dp(8), dp(4), dp(8), dp(4));
        button.setElevation(dp(2));
        int i = this.wide ? 3 : 2;
        if (this.row == null || this.row.getChildCount() >= i) {
            this.row = new LinearLayout(this);
            this.ui.addView(this.row);
        }
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, dp(56), 1.0f);
        layoutParams.setMargins(dp(3), dp(3), dp(3), dp(3));
        this.row.setWeightSum(i);
        this.row.addView(button, layoutParams);
    }

    private boolean has(String str) {
        return checkSelfPermission(str) == 0;
    }

    private void open(Intent intent) {
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            say("Uygun uygulama bulunamadı.");
        }
    }

    private void view(String str) {
        open(new Intent("android.intent.action.VIEW", Uri.parse(str)));
    }

                                                           
    public void openTelegram() {
        if (driving()) {
            say("Telegram ekranı sürüşte kapalı.");
            return;
        }
        Intent intentApp = TelegramCommand.app(this);
        if (intentApp == null) {
            say("Telegram kurulu değil.");
        } else {
            open(intentApp);
        }
    }

    private boolean telegram(String str) {
        if (this.pendingTelegram) {
            this.pendingTelegram = false;
            if (str.equalsIgnoreCase("iptal") || str.isEmpty()) {
                say("Taslak iptal edildi.");
                return true;
            }
            deliverTelegram(this.telegramRecipient, str);
            return true;
        }
        if (TelegramCommand.isOpen(str)) {
            openTelegram();
            return true;
        }
        TelegramCommand telegramCommand = TelegramCommand.parse(str, false);
        if (telegramCommand == null) {
            return false;
        }
        if (driving()) {
            say("Sürüşte yeni Telegram taslağı açılmaz; gelen mesaja yanıt verebilirsin.");
            return true;
        }
        String string = prefs(this).getString(TelegramCommand.key(telegramCommand.recipient), "");
        if (string.isEmpty() && ((telegramCommand.recipient.startsWith("@") || telegramCommand.recipient.startsWith("+")) && TelegramCommand.valid(telegramCommand.recipient))) {
            string = telegramCommand.recipient;
        }
        if (string.isEmpty()) {
            say("Önce Telegram takma adını eşleştir.");
            editTelegramAlias(telegramCommand.recipient, telegramCommand.body);
        } else {
            deliverTelegram(string, telegramCommand.body);
        }
        return true;
    }

    private void deliverTelegram(final String str, final String str2) {
        if (driving()) {
            say("Sürüşte Telegram taslağı açılmaz.");
            return;
        }
        final Intent intentApp = TelegramCommand.app(this);
        if (intentApp == null) {
            say("Telegram kurulu değil.");
            return;
        }
        if (str2.isEmpty()) {
            this.telegramRecipient = str;
            this.pendingTelegram = true;
            this.command.setHint("Mesajını yaz veya söyle…");
            say("Ne yazayım? Mesajı söyle veya yaz.");
            return;
        }
        this.command.setHint("Komut yaz…");
        say("Telegram taslağı: " + str2, false);
        new AlertDialog.Builder(this).setTitle("Telegram taslağı").setMessage(str2).setPositiveButton("Telegram'da aç", new DialogInterface.OnClickListener() {                                                                   
            @Override                                                   
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.m50lambda$deliverTelegram$19$localmertcanjarvisMain(str, str2, intentApp, dialogInterface, i);
            }
        }).setNegativeButton("İptal", (DialogInterface.OnClickListener) null).show();
    }

                                                                                                                   
                    void m50lambda$deliverTelegram$19$localmertcanjarvisMain(String str, String str2, Intent intent, DialogInterface dialogInterface, int i) {
        Intent intentDraft = TelegramCommand.draft(str, str2);
        if (intent.getComponent() != null) {
            intentDraft.setPackage(intent.getComponent().getPackageName());
        }
        open(intentDraft);
    }

    private void editTelegramAlias(final String str, final String str2) {
        if (driving()) {
            say("Takma ad ayarı sürüşte kapalı.");
            return;
        }
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setPadding(dp(16), 0, dp(16), 0);
        final EditText editText = new EditText(this);
        editText.setSingleLine(true);
        editText.setHint("Takma ad: aşkım");
        editText.setText(str);
        linearLayout.addView(editText);
        final EditText editText2 = new EditText(this);
        editText2.setSingleLine(true);
        editText2.setHint("@kullanıcıadı veya +90…");
        linearLayout.addView(editText2);
        final AlertDialog alertDialogCreate = new AlertDialog.Builder(this).setTitle("Telegram kişisini eşleştir").setView(linearLayout).setPositiveButton("Kaydet", (DialogInterface.OnClickListener) null).setNegativeButton("Vazgeç", (DialogInterface.OnClickListener) null).create();
        alertDialogCreate.show();
        alertDialogCreate.getButton(-1).setOnClickListener(new View.OnClickListener() {                                                                    
            @Override                                     
            public final void onClick(View view) {
                this.f$0.m52lambda$editTelegramAlias$20$localmertcanjarvisMain(editText, editText2, alertDialogCreate, str, str2, view);
            }
        });
    }

                                                                                                                     
                    void m52lambda$editTelegramAlias$20$localmertcanjarvisMain(EditText editText, EditText editText2, AlertDialog alertDialog, String str, String str2, View view) {
        String strTrim = editText.getText().toString().trim();
        String strTrim2 = editText2.getText().toString().trim();
        if (strTrim.isEmpty()) {
            editText.setError("Takma adı gir.");
            return;
        }
        if (!TelegramCommand.valid(strTrim2)) {
            editText2.setError("Telegram kullanıcı adı veya uluslararası numara gir.");
            return;
        }
        prefs(this).edit().putString(TelegramCommand.key(strTrim), strTrim2).apply();
        alertDialog.dismiss();
        if (!str.isEmpty()) {
            deliverTelegram(strTrim2, str2);
        } else {
            say("Telegram kişisi kaydedildi.");
        }
    }

    private void say(String str) {
        say(str, true);
    }

    private void sayAndListen(String str) {
        this.listenAfterSpeech = true;
        say(str);
    }

    private void say(String str, boolean z) {
        this.status.setText(str);
        if (z) {
            History.add(this, "Jarvis", str);
        }
        if (!VoiceDrive.active && !GeminiLive.active && this.ready) {
            this.listenAfterSpeech = this.listenAfterSpeech || LiveRepair.awaitingCallConfirmation();
            this.audio.requestAudioFocus(this.focus);
            if (this.voice.speak(str, 0, null, UUID.randomUUID().toString()) == -1) {
                this.audio.abandonAudioFocusRequest(this.focus);
                this.listenAfterSpeech = false;
            }
        }
    }

                                                           
    public void listen() {
        if (GeminiLive.active) {
            this.status.setText("Gemini Live mikrofonu kullanıyor.");
            return;
        }
        if (VoiceDrive.active) {
            this.status.setText("Eller serbest dinleyici açık. “Hey Jarvis” de.");
            return;
        }
        if (!has("android.permission.RECORD_AUDIO")) {
            requestPermissions(new String[]{"android.permission.RECORD_AUDIO"}, 1);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Bu telefonda konuşma tanıma hizmeti bulunamadı.");
            return;
        }
        if (this.voice != null) {
            this.voice.stop();
        }
        if (this.speech == null) {
            this.speech = SpeechRecognizer.createSpeechRecognizer(this);
            this.speech.setRecognitionListener(this);
        }
        this.speech.cancel();
        this.speech.startListening(new Intent("android.speech.action.RECOGNIZE_SPEECH").putExtra("android.speech.extra.LANGUAGE_MODEL", "free_form").putExtra("android.speech.extra.LANGUAGE", "tr-TR").putExtra("android.speech.extra.PREFER_OFFLINE", true));
        this.status.setText("Dinliyorum…");
    }

    @Override                        
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        DriveDashboard.onPermission(this, i);
        EvrenTalk.permission(this, i);
        if (i == 1 && has("android.permission.RECORD_AUDIO")) {
            listen();
        }
        if (i == 181) {
            if (has("android.permission.CALL_PHONE") && LiveRepair.awaitingCallConfirmation()) {
                sayAndListen("Telefon izni verildi. Aramayı başlatmak için evet de.");
            } else if (has("android.permission.READ_CONTACTS")) {
                sayAndListen("Kişiler izni verildi. Aramak istediğin kişiyi tekrar söyle.");
            }
        }
        if (i == 2 && (Build.VERSION.SDK_INT < 31 || has("android.permission.BLUETOOTH_CONNECT"))) {
            car();
        }
        if (i == 5 && has("android.permission.CAMERA") && has("android.permission.RECORD_AUDIO")) {
            confirmRecord(this.recordDual, this.recordFront);
        }
        if (i == 6 && has("android.permission.RECORD_AUDIO")) {
            enableHandsFree();
        }
        if (i == 7 && has("android.permission.POST_NOTIFICATIONS")) {
            enableHandsFree();
        }
        if (i == 8 && has("android.permission.RECORD_AUDIO")) {
            startLive();
        }
        if (i != 9 || !has("android.permission.POST_NOTIFICATIONS")) {
            return;
        }
        startLive();
    }

    private void act(String str) {
        String strReplaceFirst = str.trim().replaceFirst("(?iu)^(?:hey\\s+)?jarvis[, ]+", "");
        String strLocal = LiveRepair.local(this, strReplaceFirst);
        if (strLocal != null) {
            say(strLocal);
            return;
        }
        String strNormalize = Actions.normalize(strReplaceFirst);
        if (strNormalize.equals("gönder")) {
            say(Messages.confirm(this), false);
            return;
        }
        if (strNormalize.equals("iptal") && !this.pendingTelegram) {
            say(Messages.cancel(), false);
            return;
        }
        if (telegram(strReplaceFirst)) {
            return;
        }
        if (strReplaceFirst.matches("(?isu)^evren(?:[\\s,:]+.*)?$")) {
            evrenChat(strReplaceFirst.replaceFirst("(?iu)^evren[\\s,:]*", "").trim());
            return;
        }
        if (Actions.intent(strReplaceFirst).equals("youtube_music")) {
            say(Actions.run(this, "youtube_music", Actions.songQuery(strReplaceFirst)));
            return;
        }
        if (Cloud.isSearch(strReplaceFirst)) {
            research(Cloud.searchQuery(strReplaceFirst));
            return;
        }
        if (!strNormalize.startsWith("yanıtla ") && !strNormalize.startsWith("cevap ver ")) {
            History.add(this, "Sen", strReplaceFirst);
        }
        String lowerCase = strReplaceFirst.toLowerCase(TR);
        if (lowerCase.equals("eve git") || lowerCase.equals("eve rota") || lowerCase.equals("eve dön")) {
            home();
            return;
        }
        if (lowerCase.equals("live modu aç") || lowerCase.equals("canlı sohbet aç") || lowerCase.equals("canli modu ac")) {
            if (usingGemini()) startLive(); else startEvrenLive();
            return;
        }
        if (lowerCase.equals("live modu kapat") || lowerCase.equals("canlı sohbeti kapat")) {
            LiveRepair.stop(this);
            stopService(new Intent(this, (Class<?>) GeminiLive.class));
            return;
        }
        if (!lowerCase.equals("sürüş modu") && !lowerCase.equals("sürüş modu aç") && !lowerCase.equals("surus modu ac")) {
            if (!lowerCase.equals("sürüşü bitir")) {
                if (!lowerCase.equals("kaydı durdur")) {
                    if (lowerCase.equals("son mesajı oku") || lowerCase.equals("mesajları oku")) {
                        String strText = prefs(this).getBoolean("driving", false) ? Messages.text() : null;
                        say(strText == null ? "Sürüşte alınan destekli bir mesaj yok." : strText.substring(0, Math.min(220, strText.length())), false);
                        return;
                    }
                    if (lowerCase.startsWith("yanıtla ") || lowerCase.startsWith("cevap ver ")) {
                        if (prefs(this).getBoolean("driving", false)) {
                            say(Messages.draft(this, strReplaceFirst.substring(lowerCase.startsWith("yanıtla ") ? 8 : 10).trim()), false);
                            return;
                        } else {
                            say("Sürüş modu kapalı.");
                            return;
                        }
                    }
                    if (lowerCase.startsWith("internette ara ")) {
                        if (!prefs(this).getBoolean("driving", false)) {
                            view("https://www.google.com/search?q=" + Uri.encode(strReplaceFirst.substring(15)));
                            return;
                        } else {
                            say("Ekranlı arama sürüş modunda kapalı.");
                            return;
                        }
                    }
                    if (!lowerCase.startsWith("ara ")) {
                        if (!lowerCase.endsWith(" ara")) {
                            if (lowerCase.equals("haberler") || lowerCase.equals("haberleri oku") || lowerCase.equals("haberleri aç")) {
                                brief(false);
                                return;
                            }
                            if (lowerCase.equals("kurlar") || lowerCase.equals("kurları söyle") || lowerCase.equals("kurları aç")) {
                                brief(true);
                                return;
                            }
                            if (!lowerCase.equals("sonraki şarkı")) {
                                if (!lowerCase.equals("müziği durdur")) {
                                    if (!lowerCase.equals("müziğe devam et")) {
                                        if (!strReplaceFirst.isEmpty()) {
                                            if (usingGemini()) {
                                                geminiChat(strReplaceFirst);
                                                return;
                                            } else {
                                                evrenChat(strReplaceFirst);
                                                return;
                                            }
                                        }
                                        return;
                                    }
                                    media(126);
                                    return;
                                }
                                media(127);
                                return;
                            }
                            media(87);
                            return;
                        }
                        call(strReplaceFirst.substring(0, strReplaceFirst.length() - 4));
                        return;
                    }
                    call(strReplaceFirst.substring(4));
                    return;
                }
                stopRecord();
                return;
            }
            endDrive();
            return;
        }
        drive();
    }

    private boolean usingGemini() {
        return prefs(this).getString("provider", "evren").equals("gemini");
    }

                                                           
    public void provider() {
        if (driving()) {
            say("Sağlayıcı ayarı sürüşte kapalı.");
            return;
        }
        boolean zUsingGemini = usingGemini();
        new AlertDialog.Builder(this).setTitle("Varsayılan sohbet sağlayıcısı").setSingleChoiceItems(new String[]{"EVREN", "Gemini"}, zUsingGemini ? 1 : 0, new DialogInterface.OnClickListener() {                                                                    
            @Override                                                   
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.m85lambda$provider$21$localmertcanjarvisMain(dialogInterface, i);
            }
        }).setNegativeButton("Vazgeç", (DialogInterface.OnClickListener) null).show();
    }

                                                                                                            
                    void m85lambda$provider$21$localmertcanjarvisMain(DialogInterface dialogInterface, int i) {
        prefs(this).edit().putString("provider", i == 1 ? "gemini" : "evren").apply();
        dialogInterface.dismiss();
        recreate();
    }

    private void geminiChat(final String str) {
        final String str2 = Cloud.key;
        if (str2.isEmpty()) {
            say("Önce Gemini anahtarını gir.");
        } else {
            this.status.setText("Gemini yanıt hazırlıyor…");
            new Thread(new Runnable() {                                                                   
                @Override                      
                public final void run() {
                    this.f$0.m65lambda$geminiChat$23$localmertcanjarvisMain(str, str2);
                }
            }, "gemini-chat").start();
        }
    }

                                                                                                              
                    void m65lambda$geminiChat$23$localmertcanjarvisMain(String str, String str2) {
        final String strChat;
        try {
            strChat = Cloud.chat(str, str2);
        } catch (Exception e) {
            strChat = "Gemini yanıt vermedi; anahtarı ve bağlantıyı kontrol et.";
        }
        runOnUiThread(new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.m64lambda$geminiChat$22$localmertcanjarvisMain(strChat);
            }
        });
    }

                                                                                                              
                    void m64lambda$geminiChat$22$localmertcanjarvisMain(String str) {
        if (isDestroyed() || isFinishing()) {
            return;
        }
        say(str);
    }

    private void media(int i) {
        this.audio.dispatchMediaKeyEvent(new KeyEvent(0, i));
        this.audio.dispatchMediaKeyEvent(new KeyEvent(1, i));
    }

                                                           
    public void cloudKey() {
        if (driving()) {
            say("Anahtar ayarı sürüşte kapalı.");
            return;
        }
        final EditText editText = new EditText(this);
        editText.setSingleLine(true);
        editText.setInputType(129);
        new AlertDialog.Builder(this).setTitle("Gemini API anahtarı").setMessage("Anahtar telefonda şifreli saklanır. Google özellikleri proje kotasına veya ücrete tabi olabilir.").setView(editText).setPositiveButton("Kaydet", new DialogInterface.OnClickListener() {                                                                   
            @Override                                                   
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.m45lambda$cloudKey$24$localmertcanjarvisMain(editText, dialogInterface, i);
            }
        }).setNeutralButton("Unut", new DialogInterface.OnClickListener() {                                                                   
            @Override                                                   
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.m46lambda$cloudKey$25$localmertcanjarvisMain(dialogInterface, i);
            }
        }).setNegativeButton("Vazgeç", (DialogInterface.OnClickListener) null).show();
    }

                                                                                                            
                    void m45lambda$cloudKey$24$localmertcanjarvisMain(EditText editText, DialogInterface dialogInterface, int i) {
        saveSecret("gemini", editText.getText().toString().trim());
    }

                                                                                                            
                    void m46lambda$cloudKey$25$localmertcanjarvisMain(DialogInterface dialogInterface, int i) {
        saveSecret("gemini", "");
    }

                                                           
    public void evrenKey() {
        if (driving()) {
            say("Anahtar ayarı sürüşte kapalı.");
            return;
        }
        final EditText editText = new EditText(this);
        editText.setSingleLine(true);
        editText.setInputType(129);
        new AlertDialog.Builder(this).setTitle("EVREN API anahtarı").setMessage("EVREN komutunda soru ve seslendirilecek yanıt EVREN'e gönderilir. Anahtar telefonda şifreli saklanır.").setView(editText).setPositiveButton("Kaydet", new DialogInterface.OnClickListener() {                                                                    
            @Override                                                   
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.m60lambda$evrenKey$26$localmertcanjarvisMain(editText, dialogInterface, i);
            }
        }).setNeutralButton("Unut", new DialogInterface.OnClickListener() {                                                                    
            @Override                                                   
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.m61lambda$evrenKey$27$localmertcanjarvisMain(dialogInterface, i);
            }
        }).setNegativeButton("Vazgeç", (DialogInterface.OnClickListener) null).show();
    }

                                                                                                            
                    void m60lambda$evrenKey$26$localmertcanjarvisMain(EditText editText, DialogInterface dialogInterface, int i) {
        saveSecret("evren", editText.getText().toString().trim());
    }

                                                                                                            
                    void m61lambda$evrenKey$27$localmertcanjarvisMain(DialogInterface dialogInterface, int i) {
        saveSecret("evren", "");
    }

    private void saveSecret(String str, String str2) {
        try {
            Secrets.save(this, str, str2);
            if (str.equals("gemini")) {
                Cloud.key = str2;
                if (str2.isEmpty()) {
                    stopService(new Intent(this, (Class<?>) GeminiLive.class));
                }
            } else {
                Evren.key = str2;
                if (str2.isEmpty()) {
                    stopEvren();
                }
            }
            this.status.setText(str2.isEmpty() ? "Anahtar unutuldu." : "Anahtar telefona şifreli kaydedildi.");
        } catch (Exception e) {
            this.status.setText("Anahtar şifreli saklanamadı; ayar değiştirilmedi.");
        }
    }

    private void evrenChat(final String str) {
        if (str.isEmpty()) {
            say("EVREN'e sorunu da söyle.");
            return;
        }
        final String str2 = Evren.key;
        if (str2.isEmpty()) {
            say("Önce EVREN API anahtarını gir.");
            return;
        }
        if (GeminiLive.active || VoiceDrive.active) {
            say("Önce etkin ses oturumunu kapat.");
            return;
        }
        stopEvren();
        final int i = this.evrenGeneration;
        History.add(this, "Sen · EVREN", str);
        this.status.setText("EVREN yanıtını hazırlıyor…");
        new Thread(new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.m59lambda$evrenChat$34$localmertcanjarvisMain(str, str2, i);
            }
        }, "evren-chat").start();
    }

                                                                                                             
                    void m59lambda$evrenChat$34$localmertcanjarvisMain(String str, String str2, final int i) {
        final String strRun;
        final File fileSpeech;
        try {
            String strIntent = Actions.intent(str);
            if (strIntent.isEmpty()) {
                strRun = Evren.answer(str.substring(0, Math.min(1500, str.length())), str2);
            } else {
                strRun = Actions.run(this, strIntent, strIntent.equals("youtube_music") ? Actions.songQuery(str) : "");
            }
            runOnUiThread(new Runnable() {                                                                    
                @Override                      
                public final void run() {
                    this.f$0.m54lambda$evrenChat$29$localmertcanjarvisMain(i, strRun);
                }
            });
            try {
                fileSpeech = Evren.speech(this, strRun, str2);
            } catch (Exception e) {
                fileSpeech = null;
            }
            runOnUiThread(new Runnable() {                                                                    
                @Override                      
                public final void run() {
                    this.f$0.m58lambda$evrenChat$33$localmertcanjarvisMain(i, fileSpeech, strRun);
                }
            });
        } catch (Exception e2) {
            runOnUiThread(new Runnable() {                                                                    
                @Override                      
                public final void run() {
                    this.f$0.m53lambda$evrenChat$28$localmertcanjarvisMain(i, e2);
                }
            });
        }
    }

                                                                                                             
                    void m53lambda$evrenChat$28$localmertcanjarvisMain(int i, Exception exc) {
        if (isDestroyed() || i != this.evrenGeneration) {
            return;
        }
        say(Evren.error(exc));
    }

                                                                                                             
                    void m54lambda$evrenChat$29$localmertcanjarvisMain(int i, String str) {
        if (isDestroyed() || i != this.evrenGeneration) {
            return;
        }
        this.status.setText(str);
    }

                                                                                                             
                    void m58lambda$evrenChat$33$localmertcanjarvisMain(int i, File file, final String str) {
        if (isDestroyed() || i != this.evrenGeneration) {
            if (file != null) {
                file.delete();
                return;
            }
            return;
        }
        if (file == null) {
            say(str);
            return;
        }
        this.status.setText(str);
        History.add(this, "Jarvis · EVREN", str);
        try {
            try {
                MediaPlayer mediaPlayer = new MediaPlayer();
                this.evrenPlayer = mediaPlayer;
                mediaPlayer.setAudioAttributes(new AudioAttributes.Builder().setUsage(1).setContentType(1).build());
                FileInputStream fileInputStream = new FileInputStream(file);
                try {
                    mediaPlayer.setDataSource(fileInputStream.getFD());
                    fileInputStream.close();
                    mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {                                                                    
                        @Override                                                
                        public final void onPrepared(MediaPlayer mediaPlayer2) {
                            this.f$0.m55lambda$evrenChat$30$localmertcanjarvisMain(mediaPlayer2);
                        }
                    });
                    mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {                                                                    
                        @Override                                                  
                        public final void onCompletion(MediaPlayer mediaPlayer2) {
                            this.f$0.m56lambda$evrenChat$31$localmertcanjarvisMain(mediaPlayer2);
                        }
                    });
                    mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {                                                                    
                        @Override                                             
                        public final boolean onError(MediaPlayer mediaPlayer2, int i2, int i3) {
                            return this.f$0.m57lambda$evrenChat$32$localmertcanjarvisMain(str, mediaPlayer2, i2, i3);
                        }
                    });
                    mediaPlayer.prepareAsync();
                } catch (Throwable th) {
                    try {
                        fileInputStream.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } catch (Exception e) {
                stopEvren();
                say(str, false);
            }
            file.delete();
        } catch (Throwable th3) {
            file.delete();
            throw th3;
        }
    }

                                                                                                             
                    void m55lambda$evrenChat$30$localmertcanjarvisMain(MediaPlayer mediaPlayer) {
        if (this.evrenPlayer == mediaPlayer) {
            this.audio.requestAudioFocus(this.focus);
            mediaPlayer.start();
        }
    }

                                                                                                             
                    void m56lambda$evrenChat$31$localmertcanjarvisMain(MediaPlayer mediaPlayer) {
        if (this.evrenPlayer == mediaPlayer) {
            stopEvren();
        }
    }

                                                                                                             
                    boolean m57lambda$evrenChat$32$localmertcanjarvisMain(String str, MediaPlayer mediaPlayer, int i, int i2) {
        if (this.evrenPlayer != mediaPlayer) {
            return true;
        }
        stopEvren();
        say(str, false);
        return true;
    }

    private void stopEvren() {
        this.evrenGeneration++;
        if (this.evrenPlayer != null) {
            this.evrenPlayer.release();
            this.evrenPlayer = null;
            this.audio.abandonAudioFocusRequest(this.focus);
        }
    }

    void confirmGemini() {
        if (Cloud.key.isEmpty()) {
            say("Önce Gemini API anahtarını gir.");
        } else {
            new AlertDialog.Builder(this).setTitle("Gemini Live").setMessage("Beklerken Hey Jarvis ifadesini Android ses tanıma dinler. Cihaz içi tanıma varsa önceliklidir. Konuşma açılınca ses Google’a gönderilir. Sessiz ol diyerek beklemeye dönebilirsin.").setPositiveButton("Live başlat", new DialogInterface.OnClickListener() {                                                                   
                @Override                                                   
                public final void onClick(DialogInterface dialogInterface, int i) {
                    this.f$0.m47lambda$confirmLive$35$localmertcanjarvisMain(dialogInterface, i);
                }
            }).setNegativeButton("Vazgeç", (DialogInterface.OnClickListener) null).show();
        }
    }

                                                                                                               
                    void m47lambda$confirmLive$35$localmertcanjarvisMain(DialogInterface dialogInterface, int i) {
        startLive();
    }

    private void startLive() {
        LiveRepair.stop(this);
        stopEvren();
        if (Cloud.key.isEmpty()) {
            say("Gemini Live için API anahtarını ayarlardan ekle.");
            return;
        }
        if (!has("android.permission.RECORD_AUDIO")) {
            requestPermissions(new String[]{"android.permission.RECORD_AUDIO"}, 8);
            return;
        }
        stopService(new Intent(this, (Class<?>) VoiceDrive.class));
        DriveCamera.yieldMicrophone(this);
        if (this.speech != null) {
            this.speech.cancel();
        }
        if (this.voice != null) {
            this.voice.stop();
        }
        this.audio.abandonAudioFocusRequest(this.focus);
        try {
            startForegroundService(new Intent(this, (Class<?>) GeminiLive.class));
            this.status.setText("Gemini Live durumu bildirimde.");
        } catch (RuntimeException e) {
            this.status.setText("Live açılamadı. Jarvis ekrandayken tekrar dene.");
        }
    }

                                                           
    public void searchDialog() {
        if (driving()) {
            say("Sesle 'Google'da araştır' ve konuyu söyle.");
            return;
        }
        final EditText editText = new EditText(this);
        editText.setHint("Neyi araştırayım?");
        new AlertDialog.Builder(this).setTitle("Google araştırması ve sesli özet").setView(editText).setPositiveButton("Araştır", new DialogInterface.OnClickListener() {                                                                    
            @Override                                                   
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.m90lambda$searchDialog$36$localmertcanjarvisMain(editText, dialogInterface, i);
            }
        }).setNegativeButton("Vazgeç", (DialogInterface.OnClickListener) null).show();
    }

                                                                                                                
                    void m90lambda$searchDialog$36$localmertcanjarvisMain(EditText editText, DialogInterface dialogInterface, int i) {
        research(editText.getText().toString().trim());
    }

    private void research(final String str) {
        if (str.isEmpty()) {
            say("Araştırma konusunu da söyle.");
            return;
        }
        final String str2 = Cloud.key;
        if (str2.isEmpty()) {
            say("Google araştırması için Gemini anahtarı gerekli.");
        } else {
            this.status.setText("Google'da araştırıyorum…");
            new Thread(new Runnable() {                                                                    
                @Override                      
                public final void run() {
                    this.f$0.m89lambda$research$40$localmertcanjarvisMain(str, str2);
                }
            }, "google-search").start();
        }
    }

                                                                                                            
                    void m89lambda$research$40$localmertcanjarvisMain(String str, String str2) {
        try {
            final Cloud.Result resultResearch = Cloud.research(str, str2);
            runOnUiThread(new Runnable() {                                                                   
                @Override                      
                public final void run() {
                    this.f$0.m87lambda$research$38$localmertcanjarvisMain(resultResearch);
                }
            });
        } catch (Exception e) {
            runOnUiThread(new Runnable() {                                                                   
                @Override                      
                public final void run() {
                    this.f$0.m88lambda$research$39$localmertcanjarvisMain(e);
                }
            });
        }
    }

                                                                                                            
                    void m87lambda$research$38$localmertcanjarvisMain(Cloud.Result result) {
        if (isDestroyed() || isFinishing()) {
            return;
        }
        say(result.text);
        if (!driving()) {
            final String[] strArr = (String[]) result.sources.keySet().toArray(new String[0]);
            new AlertDialog.Builder(this).setTitle("Araştırma kaynakları").setItems((String[]) result.sources.values().toArray(new String[0]), new DialogInterface.OnClickListener() {                                                                    
                @Override                                                   
                public final void onClick(DialogInterface dialogInterface, int i) {
                    this.f$0.m86lambda$research$37$localmertcanjarvisMain(strArr, dialogInterface, i);
                }
            }).setNegativeButton("Kapat", (DialogInterface.OnClickListener) null).show();
        }
    }

                                                                                                            
                    void m86lambda$research$37$localmertcanjarvisMain(String[] strArr, DialogInterface dialogInterface, int i) {
        view(strArr[i]);
    }

                                                                                                            
                    void m88lambda$research$39$localmertcanjarvisMain(Exception exc) {
        if (isDestroyed()) {
            return;
        }
        say(((exc instanceof IOException) && exc.getMessage() != null && exc.getMessage().startsWith("Google")) ? exc.getMessage() : "Araştırma tamamlanamadı; ağ ve proje erişimini kontrol et.");
    }

    private void brief(final boolean z) {
        this.status.setText(z ? "TCMB’ye bakıyorum…" : "Haber başlıklarına bakıyorum…");
        new Thread(new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.m43lambda$brief$42$localmertcanjarvisMain(z);
            }
        }, "brief").start();
    }

                                                                                                       
                                                                                                         
    void m43lambda$brief$42$localmertcanjarvisMain(final boolean rates) {
        final String result;
        try {
            result = rates ? Brief.rates() : Brief.news();
        } catch (Exception e) {
            result = rates ? "TCMB verisi şu anda alınamadı." : "Haber başlıkları şu anda alınamadı.";
        }
        runOnUiThread(new Runnable() {
            @Override public void run() {
                Main.this.m42lambda$brief$41$localmertcanjarvisMain(result);
            }
        });
    }

                                                                                                         
                    void m42lambda$brief$41$localmertcanjarvisMain(String str) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        say(str);
    }

    private void call(String str) {
        String response = LiveRepair.local(this, "ara " + str.trim());
        say(response == null ? "Aranacak kişiyi veya numarayı anlayamadım." : response);
    }

                                                           
    public void drive() {
        Messages.clear();
        prefs(this).edit().putBoolean("driving", true).apply();
        this.status.setText("Sürüş modu açık.");
        startHandsFreeIfReady();
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override public void run() {
                if (!isFinishing() && !isDestroyed() && driving()) DriveDashboard.open(Main.this);
            }
        }, 650L);
    }

                                                                                                         
                    void m51lambda$drive$43$localmertcanjarvisMain() {
        if (isFinishing() || isDestroyed() || !driving()) {
            return;
        }
        home();
    }

    private boolean driving() {
        return prefs(this).getBoolean("driving", false);
    }

                                                           
    public void endDrive() {
        prefs(this).edit().putBoolean("driving", false).apply();
        Messages.clear();
        stopRecord();
        stopService(new Intent(this, (Class<?>) VoiceDrive.class));
        stopService(new Intent(this, (Class<?>) GeminiLive.class));
        say("Sürüş modu kapalı.");
    }

                                                           
    public void enableHandsFree() {
        if (!has("android.permission.RECORD_AUDIO")) {
            requestPermissions(new String[]{"android.permission.RECORD_AUDIO"}, 6);
        } else if (Build.VERSION.SDK_INT < 33 || has("android.permission.POST_NOTIFICATIONS")) {
            startHandsFreeIfReady();
        } else {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7);
        }
    }

    private void startHandsFreeIfReady() {
        if (GeminiLive.active) {
            this.status.setText("Gemini Live açık; yerel dinleyici başlatılmadı.");
            return;
        }
        if (!has("android.permission.RECORD_AUDIO") || (Build.VERSION.SDK_INT >= 33 && !has("android.permission.POST_NOTIFICATIONS"))) {
            this.status.setText("Eller serbest mod için mikrofon ve bildirim izinlerini ver.");
            return;
        }
        if (!LiveRepair.available(this)) {
            this.status.setText("Bu telefonda yerel ses tanıma bulunamadı. Bas-konuş kullanılabilir.");
            return;
        }
        stopEvren();
        DriveCamera.yieldMicrophone(this);
        if (this.speech != null) {
            this.speech.cancel();
        }
        if (this.voice != null) {
            this.voice.stop();
        }
        this.audio.abandonAudioFocusRequest(this.focus);
        try {
            startForegroundService(new Intent(this, (Class<?>) VoiceDrive.class));
            this.status.setText("Eller serbest dinleyici hazırlanıyor.");
        } catch (RuntimeException e) {
            this.status.setText("Dinleyici açılamadı. Uygulama ekrandayken yeniden dene.");
        }
    }

                                                           
    public void history() {
        if (driving()) {
            this.status.setText("Geçmiş ekranı sürüşte kapalı.");
            return;
        }
        TextView textView = new TextView(this);
        textView.setPadding(24, 16, 24, 16);
        textView.setText(History.display(this));
        ScrollView scrollView = new ScrollView(this);
        scrollView.addView(textView);
        final boolean z = prefs(this).getBoolean("saveHistory", true);
        new AlertDialog.Builder(this).setTitle("Telefondaki geçmiş").setView(scrollView).setPositiveButton("Kapat", (DialogInterface.OnClickListener) null).setNeutralButton(z ? "Kaydı kapat" : "Kaydı aç", new DialogInterface.OnClickListener() {                                                                    
            @Override                                                   
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.m66lambda$history$44$localmertcanjarvisMain(z, dialogInterface, i);
            }
        }).setNegativeButton("Temizle", new DialogInterface.OnClickListener() {                                                                    
            @Override                                                   
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.m68lambda$history$46$localmertcanjarvisMain(dialogInterface, i);
            }
        }).show();
    }

                                                                                                           
                    void m66lambda$history$44$localmertcanjarvisMain(boolean z, DialogInterface dialogInterface, int i) {
        prefs(this).edit().putBoolean("saveHistory", !z).apply();
    }

                                                                                                           
                    void m68lambda$history$46$localmertcanjarvisMain(DialogInterface dialogInterface, int i) {
        new AlertDialog.Builder(this).setTitle("Geçmiş silinsin mi?").setPositiveButton("Sil", new DialogInterface.OnClickListener() {                                                                    
            @Override                                                   
            public final void onClick(DialogInterface dialogInterface2, int i2) {
                this.f$0.m67lambda$history$45$localmertcanjarvisMain(dialogInterface2, i2);
            }
        }).setNegativeButton("Vazgeç", (DialogInterface.OnClickListener) null).show();
    }

                                                                                                           
                    void m67lambda$history$45$localmertcanjarvisMain(DialogInterface dialogInterface, int i) {
        History.clear(this);
    }

                                                           
    public void stopRecord() {
        stopService(new Intent(this, (Class<?>) Dashcam.class));
    }

                                                           
    public void cameraCheck() {
        try {
            boolean z = true;
            if (Dashcam.cameras((CameraManager) getSystemService(CameraManager.class), true).isEmpty()) {
                z = false;
            }
            say(Build.MANUFACTURER + " " + Build.MODEL + " · Android " + Build.VERSION.RELEASE + (z ? " · Sistem eşzamanlı ön ve arka kamerayı bildiriyor." : " · Sistem eşzamanlı ön ve arka kamera desteği bildirmiyor."));
        } catch (Exception e) {
            say("Kamera bilgisi okunamadı.");
        }
    }

    private void record(boolean z, boolean z2) {
        if (DriveCamera.requestGpsBeforeRecording(this)) {
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && !has("android.permission.POST_NOTIFICATIONS")) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 3);
            say("Kayıt bildiriminin görünmesi için izin ver, sonra tekrar dokun.");
            return;
        }
        this.recordDual = z;
        this.recordFront = z2;
        if (!has("android.permission.CAMERA") || !has("android.permission.RECORD_AUDIO")) {
            requestPermissions(new String[]{"android.permission.CAMERA", "android.permission.RECORD_AUDIO"}, 5);
        } else {
            confirmRecord(z, z2);
        }
    }

    private void confirmRecord(final boolean z, final boolean z2) {
        String str;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        if (z) {
            str = "Çift kamera kaydı";
        } else {
            str = z2 ? "Ön kamera kaydı" : "Arka kamera kaydı";
        }
        builder.setTitle(str).setMessage("Sesli kayıt, eller serbest dinlemeyi ve Gemini Live'ı durdurur. Dosyalar cihazda kalır ve yedi gün sonra temizlenir. Yolcuları bilgilendir; ayarları park hâlindeyken yap.").setPositiveButton("Kaydı başlat", new DialogInterface.OnClickListener() {                                                                    
            @Override                                                   
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.m48lambda$confirmRecord$47$localmertcanjarvisMain(z, z2, dialogInterface, i);
            }
        }).setNegativeButton("Vazgeç", (DialogInterface.OnClickListener) null).show();
    }

                                                                                                                 
                    void m48lambda$confirmRecord$47$localmertcanjarvisMain(boolean z, boolean z2, DialogInterface dialogInterface, int i) {
        int rotation = this.physicalDegrees == -1 ? getWindowManager().getDefaultDisplay().getRotation() * 90 : (360 - this.physicalDegrees) % 360;
        stopService(new Intent(this, (Class<?>) VoiceDrive.class));
        stopService(new Intent(this, (Class<?>) GeminiLive.class));
        try {
            startForegroundService(new Intent(this, (Class<?>) Dashcam.class).putExtra("sound", true).putExtra("dual", z).putExtra("front", z2).putExtra("displayDegrees", rotation));
        } catch (RuntimeException e) {
            say("Kayıt başlatılamadı.");
        }
    }

                                                           
    public void exportRecording() {
        if (driving()) {
            say("Galeriye aktarma sürüş modunda kapalı.");
            return;
        }
        if (Build.VERSION.SDK_INT < 29) {
            say("Galeriye aktarma Android 10 gerektirir.");
            return;
        }
        final File[] fileArrListFiles = Retention.directory(this).listFiles(new FilenameFilter() {                                                                    
            @Override                          
            public final boolean accept(File file, String str) {
                return str.endsWith(".mp4");
            }
        });
        if (fileArrListFiles == null || fileArrListFiles.length == 0) {
            say("Tamamlanmış kayıt yok.");
            return;
        }
        Arrays.sort(fileArrListFiles, new Comparator() {                                                                    
            @Override                        
            public final int compare(Object obj, Object obj2) {
                return ((File) obj2).getName().compareTo(((File) obj).getName());
            }
        });
        String[] strArr = new String[fileArrListFiles.length];
        for (int i = 0; i < fileArrListFiles.length; i++) {
            strArr[i] = new SimpleDateFormat("dd.MM HH:mm", TR).format(new Date(fileArrListFiles[i].lastModified())) + (namesForFront(fileArrListFiles[i]) ? " • Ön" : " • Arka");
        }
        new AlertDialog.Builder(this).setTitle("Kalıcı galeri kopyasını seç").setItems(strArr, new DialogInterface.OnClickListener() {                                                                    
            @Override                                                   
            public final void onClick(DialogInterface dialogInterface, int i2) {
                this.f$0.m63lambda$exportRecording$51$localmertcanjarvisMain(fileArrListFiles, dialogInterface, i2);
            }
        }).setNegativeButton("Vazgeç", (DialogInterface.OnClickListener) null).show();
    }

                                                                                                                   
                    void m62lambda$exportRecording$50$localmertcanjarvisMain(File[] fileArr, int i) {
        copyRecording(fileArr[i]);
    }

                                                                                                                   
                    void m63lambda$exportRecording$51$localmertcanjarvisMain(final File[] fileArr, DialogInterface dialogInterface, final int i) {
        new Thread(new Runnable() {                                                                    
            @Override                      
            public final void run() {
                this.f$0.m62lambda$exportRecording$50$localmertcanjarvisMain(fileArr, i);
            }
        }, "export").start();
    }

    private boolean namesForFront(File file) {
        return file.getName().endsWith("-on.mp4");
    }

    private void copyRecording(File file) {
        Uri uriInsert;
        final boolean z = false;
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put("_display_name", "Jarvis-" + file.getName());
            contentValues.put("mime_type", "video/mp4");
            contentValues.put("relative_path", "Movies/Jarvis");
            contentValues.put("is_pending", (Integer) 1);
            uriInsert = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues);
            try {
                if (uriInsert == null) {
                    throw new IOException();
                }
                FileInputStream fileInputStream = new FileInputStream(file);
                try {
                    OutputStream outputStreamOpenOutputStream = getContentResolver().openOutputStream(uriInsert);
                    try {
                        if (outputStreamOpenOutputStream == null) {
                            throw new IOException();
                        }
                        byte[] bArr = new byte[65536];
                        while (true) {
                            int i = fileInputStream.read(bArr);
                            if (i == -1) {
                                break;
                            } else {
                                outputStreamOpenOutputStream.write(bArr, 0, i);
                            }
                        }
                        if (outputStreamOpenOutputStream != null) {
                            outputStreamOpenOutputStream.close();
                        }
                        fileInputStream.close();
                        contentValues.clear();
                        contentValues.put("is_pending", (Integer) 0);
                        if (getContentResolver().update(uriInsert, contentValues, null, null) != 1) {
                            throw new IOException();
                        }
                        z = true;
                        runOnUiThread(new Runnable() {                                                                   
                            @Override                      
                            public final void run() {
                                this.f$0.m49lambda$copyRecording$52$localmertcanjarvisMain(z);
                            }
                        });
                    } catch (Throwable th) {
                        if (outputStreamOpenOutputStream != null) {
                            try {
                                outputStreamOpenOutputStream.close();
                            } catch (Throwable th2) {
                                th.addSuppressed(th2);
                            }
                        }
                        throw th;
                    }
                } catch (Throwable th3) {
                    try {
                        fileInputStream.close();
                    } catch (Throwable th4) {
                        th3.addSuppressed(th4);
                    }
                    throw th3;
                }
            } catch (Exception e) {
                if (uriInsert != null) {
                    try {
                        getContentResolver().delete(uriInsert, null, null);
                    } catch (Exception e2) {
                    }
                }
                runOnUiThread(new Runnable() {                                                                   
                    @Override                      
                    public final void run() {
                        this.f$0.m49lambda$copyRecording$52$localmertcanjarvisMain(z);
                    }
                });
            }
        } catch (Exception e3) {
            uriInsert = null;
        }
    }

                                                                                                                 
                    void m49lambda$copyRecording$52$localmertcanjarvisMain(boolean z) {
        if (isDestroyed()) {
            return;
        }
        say(z ? "Galeriye kalıcı kopya aktarıldı." : "Kayıt aktarılamadı.");
    }

                                                           
    public void termux() {
        if (driving()) {
            say("Termux sürüş modunda kapalı.");
            return;
        }
        Intent launchIntentForPackage = getPackageManager().getLaunchIntentForPackage("com.termux");
        if (launchIntentForPackage == null) {
            say("Termux kurulu değil.");
        } else {
            open(launchIntentForPackage);
        }
    }

                                                           
    public void home() {
        if (Build.VERSION.SDK_INT >= 28 && !((LocationManager) getSystemService(LocationManager.class)).isLocationEnabled()) {
            this.pendingHome = true;
            say("Konumu açınca rotayı başlatacağım.");
            startActivityForResult(new Intent("android.settings.LOCATION_SOURCE_SETTINGS"), 12);
            return;
        }
        launchHome();
    }

    private void launchHome() {
        String strTrim = prefs(this).getString("home", "").trim();
        if (strTrim.isEmpty()) {
            Intent launchIntentForPackage = getPackageManager().getLaunchIntentForPackage("com.google.android.apps.maps");
            if (launchIntentForPackage == null) {
                say("Google Maps kurulu değil. Jarvis'e ev adresini ekleyebilirsin.");
                return;
            } else {
                say("Google Maps açılıyor. Kayıtlı Ev kısayolunu seç.");
                open(launchIntentForPackage);
                return;
            }
        }
        view("https://www.google.com/maps/dir/?api=1&travelmode=driving&dir_action=navigate&destination=" + Uri.encode(strTrim));
    }

                                                           
                                                                                                  
    public void m83lambda$onCreate$8$localmertcanjarvisMain() {
        final EditText editText = new EditText(this);
        editText.setText(prefs(this).getString("home", ""));
        editText.setHint("Adres veya koordinatlar");
        new AlertDialog.Builder(this).setTitle("Ev adresi").setMessage("Google Maps'teki özel Ev adresini Jarvis okuyamaz. Otomatik rota için aynı adresi bir kez buraya kaydet.").setView(editText).setPositiveButton("Kaydet", new DialogInterface.OnClickListener() {                                                                   
            @Override                                                   
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.m91lambda$settingHome$53$localmertcanjarvisMain(editText, dialogInterface, i);
            }
        }).setNegativeButton("Vazgeç", (DialogInterface.OnClickListener) null).show();
    }

                                                                                                               
                    void m91lambda$settingHome$53$localmertcanjarvisMain(EditText editText, DialogInterface dialogInterface, int i) {
        prefs(this).edit().putString("home", editText.getText().toString().trim()).apply();
    }

                                                           
    public void car() {
        if (Build.VERSION.SDK_INT >= 31 && !has("android.permission.BLUETOOTH_CONNECT")) {
            requestPermissions(new String[]{"android.permission.BLUETOOTH_CONNECT"}, 2);
            return;
        }
        BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(BluetoothManager.class);
        BluetoothAdapter adapter = bluetoothManager == null ? null : bluetoothManager.getAdapter();
        final List listEmptyList = adapter == null ? Collections.emptyList() : new ArrayList(adapter.getBondedDevices());
        if (listEmptyList.isEmpty()) {
            say("Önce aracı telefonun Bluetooth ayarlarında eşleştir.");
            return;
        }
        String[] strArr = new String[listEmptyList.size()];
        for (int i = 0; i < listEmptyList.size(); i++) {
            strArr[i] = String.valueOf(((BluetoothDevice) listEmptyList.get(i)).getName());
        }
        new AlertDialog.Builder(this).setTitle("Aracı seç").setItems(strArr, new DialogInterface.OnClickListener() {                                                                    
            @Override                                                   
            public final void onClick(DialogInterface dialogInterface, int i2) {
                this.f$0.m44lambda$car$54$localmertcanjarvisMain(listEmptyList, dialogInterface, i2);
            }
        }).setNegativeButton("Vazgeç", (DialogInterface.OnClickListener) null).show();
    }

                                                                                                       
                    void m44lambda$car$54$localmertcanjarvisMain(List list, DialogInterface dialogInterface, int i) {
        prefs(this).edit().putString("car", ((BluetoothDevice) list.get(i)).getAddress()).apply();
        say("Araç kaydedildi.");
        if (Build.VERSION.SDK_INT < 33 || has("android.permission.POST_NOTIFICATIONS")) {
            return;
        }
        requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 3);
    }

    @Override                                      
    public void onResults(Bundle bundle) {
        ArrayList<String> stringArrayList = bundle.getStringArrayList("results_recognition");
        if (stringArrayList == null || stringArrayList.isEmpty()) {
            return;
        }
        act(stringArrayList.get(0));
    }

    @Override                                      
    public void onError(int i) {
        this.status.setText("Ses tanınamadı (" + i + "). Yeniden deneyebilirsin.");
    }

    @Override                                      
    public void onReadyForSpeech(Bundle bundle) {
    }

    @Override                                      
    public void onBeginningOfSpeech() {
    }

    @Override                                      
    public void onRmsChanged(float f) {
    }

    @Override                                      
    public void onBufferReceived(byte[] bArr) {
    }

    @Override                                      
    public void onEndOfSpeech() {
    }

    @Override                                      
    public void onPartialResults(Bundle bundle) {
    }

    @Override                                      
    public void onEvent(int i, Bundle bundle) {
    }

    @Override                        
    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putBoolean("homePending", this.pendingHome);
        bundle.putBoolean("telegramPending", this.pendingTelegram);
        bundle.putString("telegramRecipient", this.telegramRecipient);
    }

    @Override                        
    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 12 && this.pendingHome) {
            this.pendingHome = false;
            if (Build.VERSION.SDK_INT < 28 || !((LocationManager) getSystemService(LocationManager.class)).isLocationEnabled()) {
                this.status.setText("Konum kapalı; rota başlatılmadı.");
            } else {
                launchHome();
            }
        }
    }

    @Override                        
    protected void onResume() {
        GeminiAccess.foreground(this, true);
        super.onResume();
        visible = this;
        if (this.recordingOrientation.canDetectOrientation()) {
            this.recordingOrientation.enable();
        }
    }

    @Override                        
    protected void onPause() {
        GeminiAccess.foreground(this, false);
        EvrenTalk.suspend(this);
        DriveDashboard.suspend(this);
        if (visible == this) {
            visible = null;
        }
        this.recordingOrientation.disable();
        super.onPause();
    }

    @Override                        
    public void onDestroy() {
        stopEvren();
        unregisterReceiver(this.recordStatus);
        if (this.speech != null) {
            this.speech.destroy();
        }
        if (this.voice != null) {
            this.voice.shutdown();
        }
        this.audio.abandonAudioFocusRequest(this.focus);
        super.onDestroy();
    }
}
