package local.mertcan.jarvis;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.media.FaceDetector;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Surface;
import android.view.Gravity;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

                                          
final class DriveDashboard implements TextureView.SurfaceTextureListener {
    private static final String MAP = "<meta name='viewport' content='width=device-width,initial-scale=1'><style>body{margin:0;background:#111d2d;color:#a8bbcf;font:14px sans-serif;overflow:hidden}#tiles{position:absolute;inset:0}img{position:absolute;width:256px;height:256px}#pin{position:absolute;left:50%;top:50%;width:14px;height:14px;border:3px solid white;background:#0077ff;border-radius:100%;transform:translate(-50%,-50%);display:none}small{position:absolute;right:0;bottom:0;background:#111d2d;color:#c6d5e5;padding:4px}</style><div id='tiles' aria-label='Harita'>GPS konumu bekleniyor…</div><div id='pin'></div><small>© OpenStreetMap contributors</small><script>let tiles=document.getElementById('tiles'),pin=document.getElementById('pin'),images={},last;function moveMap(lat,lon){last=[lat,lon];let z=15,n=2**z,p=Math.max(-85,Math.min(85,lat))*Math.PI/180;let x=(lon+180)/360*n*256,y=(1-Math.asinh(Math.tan(p))/Math.PI)/2*n*256;let w=innerWidth,h=innerHeight,l=x-w/2,t=y-h/2,keep={};if(pin.style.display!='block'){tiles.textContent='';pin.style.display='block'}for(let i=Math.floor(l/256);i<=Math.floor((l+w)/256);i++)for(let j=Math.floor(t/256);j<=Math.floor((t+h)/256);j++){if(j<0||j>=n)continue;let k=i+','+j,im=images[k];if(!im){im=new Image();im.src='https://tile.openstreetmap.org/'+z+'/'+((i%n+n)%n)+'/'+j+'.png';tiles.append(im)}keep[k]=im;im.style.left=(i*256-l)+'px';im.style.top=(j*256-t)+'px'}for(let k in images)if(!keep[k])images[k].remove();images=keep}addEventListener('resize',()=>{if(last)moveMap(...last)});</script>";
    private static final String MAP_BASE = "https://local-mertcan-jarvis.invalid/";
    private final Main activity;
    private static boolean awaiting;
    private final LinearLayout cameraCard;
    private boolean closed;
    private static DriveDashboard current;
    private final Dialog dialog;
    private TextView driverStatus;
    private static volatile String frontId;
    private static volatile Surface frontSurface;
    private TextureView frontTexture;
    private static boolean hasFix;
    private static double latitude;
    private TextView liveLabel;
    private static double longitude;
    private WebView map;
    private final LinearLayout mapArea;
    private final LinearLayout mapCard;
    private boolean mapExpanded;
    private static volatile Surface previewSurface;
    private SurfaceTexture retained;
    private SurfaceTexture retainedFront;
    private boolean roadBusy;
    private int missingFaceChecks;
    private int rotationCorrection;
    private final TextView speed;
    private volatile boolean started;
    private final TextView status;
    private final TextureView texture;
    private final TextView traffic;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private final Runnable faceCheck = new Runnable() {                                                                             
        @Override                      
        public final void run() {
            this.f$0.checkFace();
        }
    };
    private final ExecutorService vision = Executors.newSingleThreadExecutor();
    private static String liveState = "Eller serbest kapalı";

    @Override                                                   
    public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
    }

    static void open(final Main main) {
        if (current != null) {
            return;
        }
        if (DriveCamera.isRecording()) {
            new AlertDialog.Builder(main).setMessage("Önizlemeli sürüş ekranı için devam eden kaydı durdur.").setPositiveButton("Kaydı durdur", new DialogInterface.OnClickListener() {                                                                             
                @Override                                                   
                public final void onClick(DialogInterface dialogInterface, int i) {
                    Main main2 = main;
                    main2.stopService(new Intent(main2, (Class<?>) Dashcam.class));
                }
            }).setNegativeButton("Kapat", (DialogInterface.OnClickListener) null).show();
            return;
        }
        ArrayList arrayList = new ArrayList();
        if (!granted(main, "android.permission.CAMERA")) {
            arrayList.add("android.permission.CAMERA");
        }
        if (!granted(main, "android.permission.ACCESS_FINE_LOCATION")) {
            arrayList.add("android.permission.ACCESS_FINE_LOCATION");
            arrayList.add("android.permission.ACCESS_COARSE_LOCATION");
        }
        if (Build.VERSION.SDK_INT >= 33 && !granted(main, "android.permission.POST_NOTIFICATIONS")) {
            arrayList.add("android.permission.POST_NOTIFICATIONS");
        }
        if (!arrayList.isEmpty() && !awaiting) {
            awaiting = true;
            main.requestPermissions((String[]) arrayList.toArray(new String[0]), 194);
        } else if (granted(main, "android.permission.CAMERA")) {
            show(main);
        }
    }

    static void suspend(Main main) {
        DriveDashboard driveDashboard = current;
        if (driveDashboard == null || driveDashboard.activity != main) {
            return;
        }
        driveDashboard.dialog.dismiss();
    }

    static void onPermission(Main main, int i) {
        if (i != 194) {
            return;
        }
        awaiting = false;
        if (!granted(main, "android.permission.CAMERA") || main.isFinishing()) {
            Toast.makeText(main, "Önizleme için kamera izni gerekli.", 1).show();
        } else {
            show(main);
        }
    }

    private static boolean granted(Main main, String str) {
        return main.checkSelfPermission(str) == 0;
    }

    private static void show(Main main) {
        if (current != null) {
            return;
        }
        hasFix = false;
        DriveDashboard driveDashboard = new DriveDashboard(main);
        current = driveDashboard;
        driveDashboard.dialog.show();
        Window window = current.dialog.getWindow();
        if (window != null) {
            window.setLayout(-1, -1);
            window.setBackgroundDrawable(new ColorDrawable(-16249578));
            window.addFlags(128);
        }
    }

    private DriveDashboard(final Main main) {
        ViewGroup.LayoutParams layoutParams;
        this.activity = main;
        this.rotationCorrection = main.getPreferences(0).getInt("drive_preview_rotation", 0);
        Dialog dialog = new Dialog(main);
        this.dialog = dialog;
        dialog.requestWindowFeature(1);
        int i = main.getResources().getConfiguration().orientation == 2 ? 1 : 0;
        LinearLayout linearLayout = new LinearLayout(main);
        linearLayout.setOrientation(1);
        linearLayout.setPadding(dp(14), dp(8), dp(14), dp(8));
        linearLayout.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{-15852757, -16249578, -15722973}));
        LinearLayout linearLayout2 = new LinearLayout(main);
        linearLayout2.setGravity(16);
        TextView textViewLabel = label("Sürüş", i != 0 ? 19 : 22);
        textViewLabel.setTypeface(Typeface.create("sans-serif-medium", 0));
        textViewLabel.setGravity(8388611);
        linearLayout2.addView(textViewLabel, new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView textViewLabel2 = label("— km/sa", i != 0 ? 23 : 29);
        this.speed = textViewLabel2;
        textViewLabel2.setTextColor(-8460305);
        textViewLabel2.setTypeface(Typeface.DEFAULT_BOLD);
        TextView textViewLabel3 = label(liveState, 11);
        this.liveLabel = textViewLabel3;
        textViewLabel3.setTextColor(-8136240);
        this.liveLabel.setMaxLines(1);
        this.liveLabel.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(0, -2, 2.0f);
        layoutParams2.rightMargin = dp(8);
        linearLayout2.addView(this.liveLabel, layoutParams2);
        linearLayout2.addView(textViewLabel2);
        linearLayout.addView(linearLayout2);
        TextView textViewLabel4 = label(granted(main, "android.permission.ACCESS_FINE_LOCATION") ? "Kamera hazırlanıyor · GPS bekleniyor" : "GPS için kesin konum izni gerekli", 12);
        this.status = textViewLabel4;
        textViewLabel4.setTextColor(-5719089);
        textViewLabel4.setGravity(8388611);
        linearLayout.addView(textViewLabel4);
        TextView textViewLabel5 = label("", 12);
        this.traffic = textViewLabel5;
        textViewLabel5.setMaxLines(2);
        textViewLabel5.setVisibility(8);
        linearLayout.addView(textViewLabel5);
        LinearLayout linearLayout3 = new LinearLayout(main);
        linearLayout3.setOrientation(i ^ 1);
        linearLayout.addView(linearLayout3, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        LinearLayout linearLayoutPanel = panel("Arka kamera");
        this.cameraCard = linearLayoutPanel;
        TextureView textureView = new TextureView(main);
        this.texture = textureView;
        textureView.setSurfaceTextureListener(this);
        FrameLayout frameLayout = new FrameLayout(main);
        frameLayout.addView(textureView, new FrameLayout.LayoutParams(-1, -1));
        linearLayoutPanel.addView(frameLayout, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        frontId = dualFrontCamera();
        if (frontId != null && main.getPreferences(0).getBoolean("drive_front_enabled", false)) {
            this.frontTexture = new TextureView(main);
            FrameLayout.LayoutParams layoutParams3 = new FrameLayout.LayoutParams(dp(120), dp(92), 8388693);
            layoutParams3.setMargins(dp(7), dp(7), dp(7), dp(7));
            frameLayout.addView(this.frontTexture, layoutParams3);
            this.frontTexture.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {                                                     
                @Override                                                   
                public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i2, int i3) {
                }

                @Override                                                   
                public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
                }

                @Override                                                   
                public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i2, int i3) {
                    if (DriveDashboard.this.closed) {
                        return;
                    }
                    surfaceTexture.setDefaultBufferSize(320, 240);
                    Surface unused = DriveDashboard.frontSurface = new Surface(surfaceTexture);
                    DriveDashboard.this.startRecordingIfReady();
                }

                @Override                                                   
                public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
                    if (!DriveDashboard.this.started || DriveDashboard.this.closed) {
                        return true;
                    }
                    DriveDashboard.this.retainedFront = surfaceTexture;
                    return false;
                }
            });
        }
        TextView textViewLabel6 = label(this.frontTexture == null ? "Ön kamera kapalı" : "Sürücü görüntüsü bekleniyor", 11);
        this.driverStatus = textViewLabel6;
        textViewLabel6.setTextColor(-5719089);
        linearLayoutPanel.addView(this.driverStatus);
        LinearLayout linearLayoutPanel2 = panel("Harita");
        this.mapCard = linearLayoutPanel2;
        LinearLayout linearLayout4 = new LinearLayout(main);
        this.mapArea = linearLayout4;
        linearLayout4.setOrientation(1);
        linearLayout4.setGravity(17);
        FrameLayout mapFrame = new FrameLayout(main);
        mapFrame.addView(linearLayout4, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout.LayoutParams cameraOverlay = new FrameLayout.LayoutParams(dp(138), dp(116), Gravity.TOP | Gravity.END);
        cameraOverlay.setMargins(0, dp(8), dp(8), 0);
        linearLayoutPanel.setElevation(dp(10));
        mapFrame.addView(linearLayoutPanel, cameraOverlay);
        linearLayoutPanel2.addView(mapFrame, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        linearLayout3.addView(linearLayoutPanel2, new LinearLayout.LayoutParams(-1, -1));
        Button buttonControl = control("Haritayı aç", -14666420, -1772545);
        buttonControl.setOnClickListener(new View.OnClickListener() {                                                                              
            @Override                                     
            public final void onClick(View view) {
                this.f$0.m13lambda$new$2$localmertcanjarvisDriveDashboard(main, view);
            }
        });
        linearLayout4.addView(buttonControl);
        LinearLayout linearLayout5 = new LinearLayout(main);
        linearLayout5.setPadding(0, dp(8), 0, 0);
        Button buttonControl2 = control("Google Maps", -15584184, -5969155);
        buttonControl2.setOnClickListener(new View.OnClickListener() {                                                                              
            @Override                                     
            public final void onClick(View view) {
                this.f$0.m14lambda$new$3$localmertcanjarvisDriveDashboard(view);
            }
        });
        addControl(linearLayout5, buttonControl2, false);
        Button buttonControl3 = control("Harita boyutu", -14997445, -2496780);
        buttonControl3.setOnClickListener(new View.OnClickListener() {                                                                              
            @Override                                     
            public final void onClick(View view) {
                this.f$0.m15lambda$new$4$localmertcanjarvisDriveDashboard(view);
            }
        });
        addControl(linearLayout5, buttonControl3, true);
        Button buttonControl4 = control("Ayarlar", -14997445, -2496780);
        buttonControl4.setOnClickListener(new View.OnClickListener() {                                                                              
            @Override                                     
            public final void onClick(View view) {
                this.f$0.m16lambda$new$5$localmertcanjarvisDriveDashboard(view);
            }
        });
        addControl(linearLayout5, buttonControl4, true);
        Button buttonControl5 = control("Kaydı bitir", -12311761, -15155);
        buttonControl5.setOnClickListener(new View.OnClickListener() {                                                                              
            @Override                                     
            public final void onClick(View view) {
                this.f$0.m17lambda$new$6$localmertcanjarvisDriveDashboard(view);
            }
        });
        addControl(linearLayout5, buttonControl5, true);
        linearLayout.addView(linearLayout5);
        dialog.setContentView(linearLayout);
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {                                                                              
            @Override                                                     
            public final void onDismiss(DialogInterface dialogInterface) {
                this.f$0.m18lambda$new$7$localmertcanjarvisDriveDashboard(dialogInterface);
            }
        });
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {                                                                              
            @Override                                                  
            public final void onShow(DialogInterface dialogInterface) {
                this.f$0.m19lambda$new$8$localmertcanjarvisDriveDashboard(main, dialogInterface);
            }
        });
    }

                                                                                                                
                    void m13lambda$new$2$localmertcanjarvisDriveDashboard(final Main main, View view) {
        if (!granted(main, "android.permission.ACCESS_FINE_LOCATION")) {
            this.status.setText("Haritada konum için kesin konum izni gerekli.");
        } else {
            new AlertDialog.Builder(main).setTitle("Çevrimiçi harita").setMessage("Haritanın görüntülenmesi için konumuna yakın harita kareleri OpenStreetMap sunucusundan istenir.").setPositiveButton("Haritayı aç", new DialogInterface.OnClickListener() {                                                                              
                @Override                                                   
                public final void onClick(DialogInterface dialogInterface, int i) {
                    this.f$0.m12lambda$new$1$localmertcanjarvisDriveDashboard(main, dialogInterface, i);
                }
            }).setNegativeButton("Vazgeç", (DialogInterface.OnClickListener) null).show();
        }
    }

                                                                                                                
                    void m12lambda$new$1$localmertcanjarvisDriveDashboard(Main main, DialogInterface dialogInterface, int i) {
        main.getPreferences(0).edit().putBoolean("drive_map", true).apply();
        showMap();
    }

                                                                                                                
                    void m14lambda$new$3$localmertcanjarvisDriveDashboard(View view) {
        openGoogleMaps();
    }

                                                                                                                
                    void m15lambda$new$4$localmertcanjarvisDriveDashboard(View view) {
        resizeMap(!this.mapExpanded);
    }

                                                                                                                
                    void m16lambda$new$5$localmertcanjarvisDriveDashboard(View view) {
        showOptions();
    }

                                                                                                                
                    void m17lambda$new$6$localmertcanjarvisDriveDashboard(View view) {
        this.dialog.dismiss();
    }

                                                                                                                
                    void m18lambda$new$7$localmertcanjarvisDriveDashboard(DialogInterface dialogInterface) {
        close();
    }

                                                                                                                
                    void m19lambda$new$8$localmertcanjarvisDriveDashboard(Main main, DialogInterface dialogInterface) {
        if (granted(main, "android.permission.ACCESS_FINE_LOCATION") && main.getPreferences(0).getBoolean("drive_map", false)) {
            showMap();
        }
    }

    static void liveStatus(String str) {
        liveState = str;
        DriveDashboard driveDashboard = current;
        if (driveDashboard == null || driveDashboard.closed) {
            return;
        }
        driveDashboard.liveLabel.setText(str);
    }

    private void showOptions() {
        new AlertDialog.Builder(this.activity).setTitle("Sürüş ayarları").setItems(new String[]{GeminiLive.active ? "Eller serbest dinlemeyi kapat" : "Hey Jarvis dinlemesini aç", "Kamera yönünü döndür", "Ön kamera ayarı", "Yol karesini incele"}, new DialogInterface.OnClickListener() {                                                                             
            @Override                                                   
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.m21lambda$showOptions$9$localmertcanjarvisDriveDashboard(dialogInterface, i);
            }
        }).setNegativeButton("Kapat", (DialogInterface.OnClickListener) null).show();
    }

                                                                                                                        
                    void m21lambda$showOptions$9$localmertcanjarvisDriveDashboard(DialogInterface dialogInterface, int i) {
        if (i == 0) {
            if (GeminiLive.active) {
                this.activity.stopService(new Intent(this.activity, (Class<?>) GeminiLive.class));
                return;
            } else {
                GeminiAccess.open(this.activity);
                return;
            }
        }
        if (i == 1) {
            this.rotationCorrection = (this.rotationCorrection + 90) % 360;
            this.activity.getPreferences(0).edit().putInt("drive_preview_rotation", this.rotationCorrection).apply();
            rotate(this.texture.getWidth(), this.texture.getHeight());
        } else if (i == 2) {
            configureFront();
        } else {
            inspectRoad();
        }
    }

    static String mapCommand(final boolean z) {
        final DriveDashboard driveDashboard = current;
        if (driveDashboard == null) {
            return "Harita boyutunu değiştirmek için sürüş ekranını aç.";
        }
        MAIN.post(new Runnable() {                                                                             
            @Override                      
            public final void run() {
                DriveDashboard.lambda$mapCommand$10(this.f$0, z);
            }
        });
        return z ? "Harita büyütülüyor." : "Harita küçültülüyor.";
    }

    static                 void lambda$mapCommand$10(DriveDashboard driveDashboard, boolean z) {
        if (driveDashboard.closed) return;
        driveDashboard.resizeMap(z);
    }

    static String frontCameraCommand(final boolean enabled) {
        final DriveDashboard dashboard = current;
        if (dashboard == null) return "Ön kamera kontrolü sürüş ekranı açıkken kullanılabilir.";
        if (enabled && dashboard.frontId == null) return "Bu telefon ön ve arka kamerayı aynı anda açmayı desteklemiyor.";
        dashboard.activity.getPreferences(0).edit().putBoolean("drive_front_enabled", enabled).apply();
        MAIN.post(new Runnable() {
            @Override public void run() {
                if (dashboard.closed) return;
                final Main activity = dashboard.activity;
                dashboard.dialog.dismiss();
                MAIN.postDelayed(new Runnable() {
                    @Override public void run() {
                        if (!activity.isFinishing() && !activity.isDestroyed()) DriveDashboard.open(activity);
                    }
                }, 450L);
            }
        });
        return enabled
                ? "Ön kamera ile yerel sürücü kontrolünü açıyorum. Görüntü kaydedilmeyecek veya gönderilmeyecek."
                : "Ön kamera kontrolünü kapatıyorum. Arka kamera ve harita devam edecek.";
    }

    static void closeFromVoice() {
        final DriveDashboard dashboard = current;
        if (dashboard != null) MAIN.post(new Runnable() {
            @Override public void run() { if (!dashboard.closed) dashboard.dialog.dismiss(); }
        });
    }

    static String cameraCommand(final boolean visible) {
        final DriveDashboard dashboard = current;
        if (dashboard == null) return "Sürüş ekranı açık değil.";
        MAIN.post(new Runnable() {
            @Override public void run() {
                if (dashboard.closed) return;
                dashboard.cameraCard.setVisibility(visible ? View.VISIBLE : View.GONE);
                if (visible) {
                    dashboard.resizeMap(dashboard.mapExpanded);
                    dashboard.startRecordingIfReady();
                } else {
                    dashboard.activity.stopService(new Intent(dashboard.activity, Dashcam.class));
                    dashboard.started = false;
                    dashboard.status.setText("Kamera kapalı · Harita açık");
                }
                dashboard.mapCard.requestLayout();
            }
        });
        return visible ? "Kamera önizlemesini açıyorum." : "Kamerayı kapattım. Harita açık kalıyor.";
    }

    private void resizeMap(boolean expanded) {
        this.mapExpanded = expanded;
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) this.cameraCard.getLayoutParams();
        lp.width = dp(expanded ? 116 : 160);
        lp.height = dp(expanded ? 98 : 132);
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.setMargins(0, dp(8), dp(8), 0);
        this.cameraCard.setLayoutParams(lp);
        this.cameraCard.setAlpha(1.0f);
        this.cameraCard.setElevation(dp(10));
        this.mapCard.requestLayout();
    }

    private String dualFrontCamera() {
        if (Build.VERSION.SDK_INT < 30) {
            return null;
        }
        CameraManager cameraManager = (CameraManager) this.activity.getSystemService(CameraManager.class);
        try {
            Iterator<Set<String>> it = cameraManager.getConcurrentCameraIds().iterator();
            while (it.hasNext()) {
                String str = null;
                boolean z = false;
                for (String str2 : it.next()) {
                    Integer num = (Integer) cameraManager.getCameraCharacteristics(str2).get(CameraCharacteristics.LENS_FACING);
                    Integer num2 = 1;
                    if (num2.equals(num)) {
                        z = true;
                    }
                    Integer num3 = 0;
                    if (num3.equals(num)) {
                        str = str2;
                    }
                }
                if (z && str != null) {
                    return str;
                }
            }
        } catch (Exception unused) {
        }
        return null;
    }

    private void configureFront() {
        String str;
        if (dualFrontCamera() == null) {
            this.status.setText("Telefon ön ve arka kameranın eşzamanlı açılmasını desteklemiyor.");
            return;
        }
        final boolean z = this.frontTexture != null;
        AlertDialog.Builder title = new AlertDialog.Builder(this.activity).setTitle("Ön kamera");
        if (z) {
            str = "Bir sonraki sürüş ekranında ön kamera kontrolünü kapat.";
        } else {
            str = "Ön kamera yalnızca cihaz üzerinde sürücü yüzünün görünürlüğünü kontrol eder. Ön kamera kaydı oluşturulmaz ve görüntü EVREN'e gönderilmez.";
        }
        title.setMessage(str).setPositiveButton(z ? "Sonraki sürüşte kapat" : "Sonraki sürüşte aç", new DialogInterface.OnClickListener() {                                                                              
            @Override                                                   
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.m8lambda$configureFront$11$localmertcanjarvisDriveDashboard(z, dialogInterface, i);
            }
        }).setNegativeButton("Vazgeç", (DialogInterface.OnClickListener) null).show();
    }

                                                                                                                            
                    void m8lambda$configureFront$11$localmertcanjarvisDriveDashboard(boolean z, DialogInterface dialogInterface, int i) {
        this.activity.getPreferences(0).edit().putBoolean("drive_front_enabled", !z).apply();
        this.status.setText("Ön kamera ayarını uygulamak için sürüş ekranını yeniden aç.");
    }

                                                           
    public void checkFace() {
        TextureView textureView;
        if (this.closed || (textureView = this.frontTexture) == null) {
            return;
        }
        final Bitmap bitmap = textureView.isAvailable() ? this.frontTexture.getBitmap(160, 120) : null;
        if (bitmap != null) {
            this.vision.execute(new Runnable() {                                                                             
                @Override                      
                public final void run() {
                    this.f$0.m7lambda$checkFace$13$localmertcanjarvisDriveDashboard(bitmap);
                }
            });
        }
        MAIN.postDelayed(this.faceCheck, 2500L);
    }

                                                                  
                                                                                                                                
                                                                                                                                                                                    
                                                                                                                       
                    void m7lambda$checkFace$13$localmertcanjarvisDriveDashboard(Bitmap bitmap) {
        final boolean z = false;
        Bitmap bitmapCopy = null;
        try {
            bitmapCopy = bitmap.copy(Bitmap.Config.RGB_565, false);
            z = new FaceDetector(160, 120, 1).findFaces(bitmapCopy, new FaceDetector.Face[1]) > 0;
            if (bitmapCopy != null) {
                bitmapCopy.recycle();
            }
        } catch (RuntimeException unused) {
            if (bitmapCopy != null) {
                bitmapCopy.recycle();
            }
        } catch (Throwable th) {
            if (bitmapCopy != null) {
                bitmapCopy.recycle();
            }
            bitmap.recycle();
            throw th;
        }
        bitmap.recycle();
        MAIN.post(new Runnable() {                                                                             
            @Override                      
            public final void run() {
                this.f$0.m6lambda$checkFace$12$localmertcanjarvisDriveDashboard(z);
            }
        });
    }

                                                                                                                       
                    void m6lambda$checkFace$12$localmertcanjarvisDriveDashboard(boolean z) {
        if (this.closed) return;
        if (z) {
            this.missingFaceChecks = 0;
            this.driverStatus.setText("Sürücü algılandı · Yerel kontrol");
        } else {
            this.missingFaceChecks++;
            this.driverStatus.setText("Yüz görünmüyor · Kamerayı kontrol et");
            if (this.missingFaceChecks >= 4) {
                this.status.setText("Sürücü yüzü birkaç kontroldür algılanmadı. Kamera açısını ve yola dikkatini kontrol et.");
                this.missingFaceChecks = 0;
            }
        }
    }

    private void inspectRoad() {
        if (!this.texture.isAvailable() || this.mapExpanded || !this.started) {
            this.status.setText("İnceleme için arka kamera önizlemesi gerekli.");
        } else {
            if (this.roadBusy) {
                return;
            }
            new AlertDialog.Builder(this.activity).setTitle("Yol görüntüsünü incele").setMessage("Arka kameradan bir kare EVREN’e gönderilir. Plaka gibi bilgiler görüntüde bulunabilir.").setPositiveButton("Kareyi gönder", new DialogInterface.OnClickListener() {                                                                              
                @Override                                                   
                public final void onClick(DialogInterface dialogInterface, int i) {
                    this.f$0.m11lambda$inspectRoad$16$localmertcanjarvisDriveDashboard(dialogInterface, i);
                }
            }).setNegativeButton("Vazgeç", (DialogInterface.OnClickListener) null).show();
        }
    }

                                                                                                                         
                    void m11lambda$inspectRoad$16$localmertcanjarvisDriveDashboard(DialogInterface dialogInterface, int i) {
        final Bitmap bitmap;
        if (this.closed || this.roadBusy || (bitmap = this.texture.getBitmap(640, 480)) == null) {
            return;
        }
        this.roadBusy = true;
        this.status.setText("Yol karesi inceleniyor…");
        this.vision.execute(new Runnable() {                                                                             
            @Override                      
            public final void run() {
                this.f$0.m10lambda$inspectRoad$15$localmertcanjarvisDriveDashboard(bitmap);
            }
        });
    }

                                                                                                                         
                    void m10lambda$inspectRoad$15$localmertcanjarvisDriveDashboard(Bitmap bitmap) {
        final String strDescribeRoad;
        try {
            strDescribeRoad = DriveCamera.describeRoad(bitmap);
        } catch (Exception unused) {
            strDescribeRoad = "EVREN yol karesini inceleyemedi.";
        } finally {
            bitmap.recycle();
        }
        MAIN.post(new Runnable() {                                                                             
            @Override                      
            public final void run() {
                this.f$0.m9lambda$inspectRoad$14$localmertcanjarvisDriveDashboard(strDescribeRoad);
            }
        });
    }

                                                                                                                         
                    void m9lambda$inspectRoad$14$localmertcanjarvisDriveDashboard(String str) {
        this.roadBusy = false;
        if (this.closed) {
            return;
        }
        this.status.setText(str);
    }

    private int dp(int i) {
        return Math.round(i * this.activity.getResources().getDisplayMetrics().density);
    }

    private GradientDrawable rounded(int i, int i2) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(i);
        gradientDrawable.setCornerRadius(dp(i2));
        return gradientDrawable;
    }

    private LinearLayout panel(String str) {
        LinearLayout linearLayout = new LinearLayout(this.activity);
        linearLayout.setOrientation(1);
        GradientDrawable gradientDrawableRounded = rounded(-15524565, 20);
        gradientDrawableRounded.setStroke(dp(1), -14076086);
        linearLayout.setBackground(gradientDrawableRounded);
        linearLayout.setClipToOutline(true);
        TextView textViewLabel = label(str, 13);
        textViewLabel.setTextColor(-4337436);
        textViewLabel.setGravity(8388611);
        linearLayout.addView(textViewLabel);
        return linearLayout;
    }

    private Button control(String str, int i, int i2) {
        Button button = new Button(this.activity);
        button.setText(str);
        button.setAllCaps(false);
        button.setTextSize(13.0f);
        button.setTextColor(i2);
        button.setMinHeight(0);
        button.setMinimumHeight(0);
        button.setPadding(dp(6), 0, dp(6), 0);
        button.setBackground(new RippleDrawable(ColorStateList.valueOf(922746879), rounded(i, 16), null));
        return button;
    }

    private void addControl(LinearLayout linearLayout, Button button, boolean z) {
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, dp(48), 1.0f);
        if (z) {
            layoutParams.leftMargin = dp(8);
        }
        linearLayout.addView(button, layoutParams);
    }

    private void openGoogleMaps() {
        new AlertDialog.Builder(this.activity).setTitle("Google Maps").setMessage("Google Maps açıldığında bu JARVIS önizleme kaydı kapanır.").setPositiveButton("Google Maps’i aç", new DialogInterface.OnClickListener() {                                                                              
            @Override                                                   
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.m20lambda$openGoogleMaps$17$localmertcanjarvisDriveDashboard(dialogInterface, i);
            }
        }).setNegativeButton("Vazgeç", (DialogInterface.OnClickListener) null).show();
    }

                                                                                                                            
                    void m20lambda$openGoogleMaps$17$localmertcanjarvisDriveDashboard(DialogInterface dialogInterface, int i) {
        String str = hasFix ? String.format(Locale.US, "%.6f,%.6f", Double.valueOf(latitude), Double.valueOf(longitude)) : "";
        Uri.Builder builderAppendQueryParameter = Uri.parse("https://www.google.com/maps/@").buildUpon().appendQueryParameter("api", "1").appendQueryParameter("map_action", "map");
        if (!str.isEmpty()) {
            builderAppendQueryParameter.appendQueryParameter("center", str).appendQueryParameter("zoom", "16");
        }
        try {
            try {
                this.activity.startActivity(new Intent("android.intent.action.VIEW", builderAppendQueryParameter.build()).setPackage("com.google.android.apps.maps"));
            } catch (ActivityNotFoundException unused) {
                this.activity.startActivity(new Intent("android.intent.action.VIEW", builderAppendQueryParameter.build()));
            }
        } catch (ActivityNotFoundException unused2) {
            this.status.setText("Google Maps açılamadı.");
        }
    }

    private TextView label(String str, int i) {
        TextView textView = new TextView(this.activity);
        textView.setText(str);
        textView.setTextColor(-1);
        textView.setTextSize(i);
        textView.setGravity(17);
        textView.setPadding(10, 6, 10, 6);
        return textView;
    }

    @Override                                                   
    public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i2) {
        if (this.closed) {
            return;
        }
        surfaceTexture.setDefaultBufferSize(640, 480);
        rotate(i, i2);
        if (this.started) {
            return;
        }
        previewSurface = new Surface(surfaceTexture);
        startRecordingIfReady();
    }

                                                           
    public void startRecordingIfReady() {
        if (this.closed || this.started || previewSurface == null) {
            return;
        }
        if (this.frontTexture == null || frontSurface != null) {
            try {
                this.activity.startForegroundService(new Intent(this.activity, (Class<?>) Dashcam.class)
                        .putExtra("sound", false)
                        .putExtra("front", false)
                        .putExtra("dual", this.frontTexture != null)
                        .putExtra("frontPreviewOnly", this.frontTexture != null)
                        .putExtra("displayDegrees", this.activity.getWindowManager().getDefaultDisplay().getRotation() * 90));
                this.started = true;
                if (this.frontTexture != null) {
                    MAIN.postDelayed(this.faceCheck, 2500L);
                }
            } catch (RuntimeException unused) {
                this.status.setText("Kamera kaydı başlatılamadı.");
            }
        }
    }

    @Override                                                   
    public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i2) {
        rotate(i, i2);
    }

    @Override                                                   
    public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
        if (!this.started || this.closed) {
            return true;
        }
        this.retained = surfaceTexture;
        return false;
    }

    private void rotate(int i, int i2) {
        int iIntValue;
        try {
            CameraManager cameraManager = (CameraManager) this.activity.getSystemService(CameraManager.class);
            String[] cameraIdList = cameraManager.getCameraIdList();
            int length = cameraIdList.length;
            int i3 = 0;
            while (true) {
                if (i3 < length) {
                    CameraCharacteristics cameraCharacteristics = cameraManager.getCameraCharacteristics(cameraIdList[i3]);
                    Integer num = 1;
                    if (num.equals(cameraCharacteristics.get(CameraCharacteristics.LENS_FACING))) {
                        Integer num2 = (Integer) cameraCharacteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
                        if (num2 != null) {
                            iIntValue = num2.intValue();
                            break;
                        }
                    } else {
                        i3++;
                    }
                }
                iIntValue = 90;
                break;
            }
        } catch (Exception unused) {
        }
        int rotation = (((iIntValue - (this.activity.getWindowManager().getDefaultDisplay().getRotation() * 90)) + this.rotationCorrection) + 360) % 360;
        boolean z = rotation == 90 || rotation == 270;
        if (i == 0 || i2 == 0) {
            return;
        }
        float f = i;
        float f2 = i2;
        float fMax = Math.max(f / (z ? 480.0f : 640.0f), f2 / (z ? 640.0f : 480.0f));
        Matrix matrix = new Matrix();
        matrix.postTranslate((-i) / 2.0f, (-i2) / 2.0f);
        matrix.postScale((640.0f * fMax) / f, (fMax * 480.0f) / f2);
        matrix.postRotate(rotation);
        matrix.postTranslate(f / 2.0f, f2 / 2.0f);
        this.texture.setTransform(matrix);
    }

    private void close() {
        this.closed = true;
        Handler handler = MAIN;
        handler.removeCallbacks(this.faceCheck);
        this.vision.shutdownNow();
        if (current == this) {
            current = null;
        }
        final Surface surface = previewSurface;
        previewSurface = null;
        final Surface surface2 = frontSurface;
        frontSurface = null;
        frontId = null;
        final SurfaceTexture surfaceTexture = this.retainedFront;
        if (this.started) {
            this.activity.stopService(new Intent(this.activity, (Class<?>) Dashcam.class));
        }
        final SurfaceTexture surfaceTexture2 = this.retained;
        handler.postDelayed(new Runnable() {                                                                             
            @Override                      
            public final void run() {
                DriveDashboard.lambda$close$18(surface, surfaceTexture2, surface2, surfaceTexture);
            }
        }, 800L);
        WebView webView = this.map;
        if (webView != null) {
            this.mapArea.removeView(webView);
            this.map.destroy();
            this.map = null;
        }
    }

    static                 void lambda$close$18(Surface surface, SurfaceTexture surfaceTexture, Surface surface2, SurfaceTexture surfaceTexture2) {
        if (surface != null) {
            surface.release();
        }
        if (surfaceTexture != null) {
            surfaceTexture.release();
        }
        if (surface2 != null) {
            surface2.release();
        }
        if (surfaceTexture2 != null) {
            surfaceTexture2.release();
        }
    }

    static void cameraStatus(final String str) {
        MAIN.post(new Runnable() {                                                                             
            @Override                      
            public final void run() {
                DriveDashboard.lambda$cameraStatus$19(str);
            }
        });
    }

    static                 void lambda$cameraStatus$19(String str) {
        DriveDashboard driveDashboard = current;
        if (driveDashboard != null) {
            driveDashboard.status.setText(str);
        }
    }

    static void position(double d, double d2) {
        latitude = d;
        longitude = d2;
        hasFix = true;
        DriveDashboard driveDashboard = current;
        if (driveDashboard != null) {
            driveDashboard.updateMap();
        }
    }

    static void gps(int i, int i2, String str) {
        DriveDashboard driveDashboard = current;
        if (driveDashboard == null) {
            return;
        }
        driveDashboard.speed.setText(i + " km/sa  ·  " + i2 + " m / 2 sn");
        driveDashboard.traffic.setText(str);
        driveDashboard.traffic.setVisibility(str.isEmpty() ? 8 : 0);
    }

    static void gpsUnavailable() {
        DriveDashboard driveDashboard = current;
        if (driveDashboard != null) {
            driveDashboard.speed.setText("— km/sa · GPS hızı bekleniyor");
            driveDashboard.traffic.setVisibility(8);
        }
    }

    private void showMap() {
        if (current == this && this.map == null) {
            WebView webView = new WebView(this.activity);
            this.map = webView;
            webView.getSettings().setJavaScriptEnabled(true);
            this.map.getSettings().setAllowFileAccess(false);
            this.map.getSettings().setAllowContentAccess(false);
            this.map.getSettings().setUserAgentString(this.map.getSettings().getUserAgentString() + " JarvisAndroid/0.9.4");
            this.map.setWebViewClient(new WebViewClient() {                                                     
                @Override                                
                public boolean shouldOverrideUrlLoading(WebView webView2, WebResourceRequest webResourceRequest) {
                    return true;
                }

                @Override                                
                public void onPageFinished(WebView webView2, String str) {
                    DriveDashboard.this.updateMap();
                }
            });
            this.mapArea.removeAllViews();
            this.mapArea.addView(this.map, new LinearLayout.LayoutParams(-1, -1));
            this.map.loadDataWithBaseURL(MAP_BASE, MAP, "text/html", "UTF-8", MAP_BASE);
        }
    }

                                                           
    public void updateMap() {
        WebView webView = this.map;
        if (webView == null || !hasFix) {
            return;
        }
        webView.evaluateJavascript(String.format(Locale.US, "if(window.moveMap)moveMap(%.6f,%.6f)", Double.valueOf(latitude), Double.valueOf(longitude)), null);
    }

    static void createPreviewSession(CameraDevice cameraDevice, CaptureRequest.Builder builder,
                                     CameraCaptureSession.StateCallback callback, Handler handler) throws Exception {
        Surface surface = frontSurface;
        if (surface == null || !surface.isValid()) throw new IllegalStateException("Ön kamera önizleme yüzeyi hazır değil.");
        builder.addTarget(surface);
        cameraDevice.createCaptureSession(Collections.singletonList(surface), callback, handler);
    }

    static void createSession(final CameraDevice cameraDevice, final Surface surface, final CaptureRequest.Builder builder, final CameraCaptureSession.StateCallback stateCallback, final Handler handler) throws Exception {
        Surface surface2 = cameraDevice.getId().equals(frontId) ? frontSurface : previewSurface;
        if (surface2 == null || !surface2.isValid()) {
            cameraDevice.createCaptureSession(Collections.singletonList(surface), stateCallback, handler);
            return;
        }
        final Surface surface3 = surface2;
        CameraCaptureSession.StateCallback stateCallback2 = new CameraCaptureSession.StateCallback() {                                                     
            @Override                                                               
            public void onConfigured(CameraCaptureSession cameraCaptureSession) {
                stateCallback.onConfigured(cameraCaptureSession);
            }

            @Override                                                               
            public void onConfigureFailed(CameraCaptureSession cameraCaptureSession) {
                cameraCaptureSession.close();
                try {
                    retry();
                } catch (Exception unused) {
                    stateCallback.onConfigureFailed(cameraCaptureSession);
                }
            }

            void retry() throws Exception {
                builder.removeTarget(surface3);
                DriveDashboard.cameraStatus("Bu kamera, kayıtla birlikte önizleme açamadı. Kayıt sürüyor.");
                cameraDevice.createCaptureSession(Collections.singletonList(surface), stateCallback, handler);
            }
        };
        builder.addTarget(surface2);
        try {
            cameraDevice.createCaptureSession(Arrays.asList(surface, surface2), stateCallback2, handler);
        } catch (Exception unused) {
            builder.removeTarget(surface2);
            cameraStatus("Bu kamera, kayıtla birlikte önizleme açamadı.");
            cameraDevice.createCaptureSession(Collections.singletonList(surface), stateCallback, handler);
        }
    }
}
