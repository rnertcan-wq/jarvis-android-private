package local.mertcan.jarvis;

                                                  
                                          
public final                 class GeminiLive$$ExternalSyntheticLambda4 implements Runnable {
    public final                 GeminiLive f$0;

    public                 GeminiLive$$ExternalSyntheticLambda4(GeminiLive geminiLive) {
        this.f$0 = geminiLive;
    }

    @Override                      
    public final void run() {
        this.f$0.waitForWake();
    }
}
