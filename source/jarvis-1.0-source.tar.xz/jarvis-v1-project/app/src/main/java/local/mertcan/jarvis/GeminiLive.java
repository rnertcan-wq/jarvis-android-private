package local.mertcan.jarvis;

import android.R;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.audiofx.AcousticEchoCanceler;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.SpeechRecognizer;
import android.util.Base64;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

                                          
public final class GeminiLive extends Service {
    private static final String CHANNEL = "gemini-live";
    private static final int NOTICE = 84;
    private static final String STOP = "local.mertcan.jarvis.STOP_LIVE";
    static volatile boolean active;
    private Thread input;
    private boolean onDeviceWake;
    private Thread output;
    private volatile boolean ready;
    private volatile boolean running;
    private volatile WebSocket socket;
    private boolean useDefaultRecognizer;
    private int wakeErrors;
    private SpeechRecognizer wakeRecognizer;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ArrayBlockingQueue<byte[]> playback = new ArrayBlockingQueue<>(120);
    private final ExecutorService tools = Executors.newSingleThreadExecutor();
    private final StringBuilder transcript = new StringBuilder();
    private String openingWords = "";
    private final OkHttpClient client = new OkHttpClient.Builder().pingInterval(25, TimeUnit.SECONDS).build();

    @Override                       
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override                       
    public int onStartCommand(Intent intent, int i, int i2) {
        if (intent == null || STOP.equals(intent.getAction())) {
            stopSelf();
            return 2;
        }
        if (this.running) {
            return 2;
        }
        try {
            ((NotificationManager) getSystemService(NotificationManager.class)).createNotificationChannel(new NotificationChannel(CHANNEL, "Gemini Live", 2));
            Notification notification = notification("Google’a bağlanıyor…");
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTICE, notification, 128);
            } else {
                startForeground(NOTICE, notification);
            }
            if (Cloud.key != null && !Cloud.key.isEmpty()) {
                this.running = true;
                active = true;
                waitForWake();
                return 2;
            }
            fail("Gemini API anahtarını gir.");
            return 2;
        } catch (LinkageError | RuntimeException e) {
            fail(GeminiAccess.startupFailure(e));
        }
    }

                                                           
    public void waitForWake() {
        Thread thread;
        if (this.running && this.socket == null) {
            Thread thread2 = this.input;
            if ((thread2 != null && thread2.isAlive()) || ((thread = this.output) != null && thread.isAlive())) {
                this.main.postDelayed(new GeminiLive$$ExternalSyntheticLambda4(this), 120L);
                return;
            }
            try {
                if (this.wakeRecognizer == null) {
                    boolean z = !this.useDefaultRecognizer && Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this);
                    this.onDeviceWake = z;
                    if (!z && !SpeechRecognizer.isRecognitionAvailable(this)) {
                        fail("Hey Jarvis için telefonda Android ses tanıma hizmeti gerekli.");
                        return;
                    }
                    SpeechRecognizer speechRecognizerCreateOnDeviceSpeechRecognizer = this.onDeviceWake ? SpeechRecognizer.createOnDeviceSpeechRecognizer(this) : SpeechRecognizer.createSpeechRecognizer(this);
                    this.wakeRecognizer = speechRecognizerCreateOnDeviceSpeechRecognizer;
                    speechRecognizerCreateOnDeviceSpeechRecognizer.setRecognitionListener(new WakeListener());
                    state("Beklemede · Hey Jarvis");
                }
                this.wakeRecognizer.startListening(new Intent("android.speech.action.RECOGNIZE_SPEECH").putExtra("android.speech.extra.LANGUAGE_MODEL", "free_form").putExtra("android.speech.extra.LANGUAGE", "tr-TR").putExtra("android.speech.extra.PREFER_OFFLINE", this.onDeviceWake).putExtra("android.speech.extra.MAX_RESULTS", 3));
            } catch (RuntimeException e) {
                fail("Hey Jarvis dinleyicisi açılamadı · " + e.getClass().getSimpleName());
            }
        }
    }

                                                           
    final class WakeListener implements RecognitionListener {
        @Override                                      
        public void onBeginningOfSpeech() {
        }

        @Override                                      
        public void onBufferReceived(byte[] bArr) {
        }

        @Override                                      
        public void onEndOfSpeech() {
        }

        @Override                                      
        public void onEvent(int i, Bundle bundle) {
        }

        @Override                                      
        public void onPartialResults(Bundle bundle) {
        }

        @Override                                      
        public void onReadyForSpeech(Bundle bundle) {
        }

        @Override                                      
        public void onRmsChanged(float f) {
        }

        private WakeListener() {
        }

        @Override                                      
        public void onError(int i) {
            if (GeminiLive.this.running && GeminiLive.this.socket == null && GeminiLive.this.wakeRecognizer != null) {
                if (i == 9) {
                    GeminiLive.this.fail("Hey Jarvis için mikrofon izni gerekli.");
                    return;
                }
                if (GeminiLive.this.onDeviceWake && (i == 12 || i == 13)) {
                    if (!SpeechRecognizer.isRecognitionAvailable(GeminiLive.this)) {
                        GeminiLive.this.fail("Cihaz içi Türkçe ses tanıma kullanılamıyor.");
                        return;
                    }
                    GeminiLive.this.useDefaultRecognizer = true;
                    GeminiLive.this.closeWakeRecognizer();
                    Handler handler = GeminiLive.this.main;
                    final GeminiLive geminiLive = GeminiLive.this;
                    handler.postDelayed(new Runnable() {                                                                                      
                        @Override                      
                        public final void run() {
                            geminiLive.waitForWake();
                        }
                    }, 450L);
                    return;
                }
                GeminiLive geminiLive2 = GeminiLive.this;
                geminiLive2.wakeErrors = Math.min(8, geminiLive2.wakeErrors + 1);
                Handler handler2 = GeminiLive.this.main;
                final GeminiLive geminiLive3 = GeminiLive.this;
                handler2.postDelayed(new Runnable() {                                                                                      
                    @Override                      
                    public final void run() {
                        geminiLive3.waitForWake();
                    }
                }, Math.min(4000L, ((long) GeminiLive.this.wakeErrors) * 250));
            }
        }

        @Override                                      
        public void onResults(Bundle bundle) {
            if (GeminiLive.this.running && GeminiLive.this.socket == null && GeminiLive.this.wakeRecognizer != null) {
                GeminiLive.this.wakeErrors = 0;
                ArrayList<String> stringArrayList = bundle.getStringArrayList("results_recognition");
                if (stringArrayList != null) {
                    for (String str : stringArrayList) {
                        if (str != null) {
                            Matcher matcher = Pattern.compile("(?iu)^\\s*(?:hey|ey)\\s*[, ]*\\s*(?:jarvis|carvis|carvıs|carviz|jarvıs)\\b[ ,.!?]*").matcher(str);
                            if (matcher.find()) {
                                GeminiLive.this.wake(str.substring(matcher.end()).trim());
                                return;
                            }
                        }
                    }
                }
                Handler handler = GeminiLive.this.main;
                final GeminiLive geminiLive = GeminiLive.this;
                handler.postDelayed(new Runnable() {                                                                                      
                    @Override                      
                    public final void run() {
                        geminiLive.waitForWake();
                    }
                }, 250L);
            }
        }
    }

                                                           
    public void wake(String str) {
        closeWakeRecognizer();
        try {
            AudioManager audioManager = (AudioManager) getSystemService(AudioManager.class);
            if (audioManager != null && audioManager.isMusicActive()) {
                GeminiAccess.dispatchDeviceTool(this, "stop_music", new JSONObject());
            }
            this.openingWords = str;
            state("Hey Jarvis algılandı · bağlanıyor");
            this.socket = this.client.newWebSocket(new Request.Builder().url(GeminiAccess.liveUrl()).build(), new Listener());
            final WebSocket webSocket = this.socket;
            this.main.postDelayed(new Runnable() {                                                                         
                @Override                      
                public final void run() {
                    this.f$0.m35lambda$wake$0$localmertcanjarvisGeminiLive(webSocket);
                }
            }, 22000L);
        } catch (RuntimeException e) {
            sleep(GeminiAccess.startupFailure(e));
        }
    }

                                                                                                             
                    void m35lambda$wake$0$localmertcanjarvisGeminiLive(WebSocket webSocket) {
        if (this.socket != webSocket || this.ready) {
            return;
        }
        sleep("Gemini Live yanıt vermedi.");
    }

                                                           
    public void closeWakeRecognizer() {
        SpeechRecognizer speechRecognizer = this.wakeRecognizer;
        if (speechRecognizer == null) {
            return;
        }
        this.wakeRecognizer = null;
        speechRecognizer.destroy();
    }

    private void state(String str) {
        ((NotificationManager) getSystemService(NotificationManager.class)).notify(NOTICE, notification(str));
        GeminiAccess.reportStatus(str);
    }

    private void sleep(String str) {
        if (this.running) {
            WebSocket webSocket = this.socket;
            this.socket = null;
            this.ready = false;
            if (webSocket != null) {
                webSocket.cancel();
            }
            Thread thread = this.input;
            if (thread != null) {
                thread.interrupt();
            }
            Thread thread2 = this.output;
            if (thread2 != null) {
                thread2.interrupt();
            }
            this.playback.clear();
            LiveRepair.clearGeminiPlayback();
            state(str + " · Hey Jarvis bekleniyor");
            this.main.postDelayed(new GeminiLive$$ExternalSyntheticLambda4(this), 450L);
        }
    }

                                                                                                                     
                    void m34lambda$sessionError$1$localmertcanjarvisGeminiLive(WebSocket webSocket, String str) {
        if (this.socket == webSocket) {
            sleep(str);
        }
    }

                                                           
    public void sessionError(final WebSocket webSocket, final String str) {
        this.main.post(new Runnable() {                                                                         
            @Override                      
            public final void run() {
                this.f$0.m34lambda$sessionError$1$localmertcanjarvisGeminiLive(webSocket, str);
            }
        });
    }

    private final class Listener extends WebSocketListener {
        private Listener() {
        }

        @Override                             
        public void onOpen(WebSocket webSocket, Response response) {
            try {
                if (!GeminiLive.this.running || webSocket.send(GeminiAccess.setup())) {
                    return;
                }
                GeminiLive.this.sessionError(webSocket, "Gemini Live açılış mesajı gönderilemedi.");
            } catch (Exception | LinkageError e) {
                GeminiLive.this.sessionError(webSocket, GeminiAccess.startupFailure(e));
            }
        }

        @Override                             
        public void onMessage(WebSocket webSocket, String str) {
            GeminiLive.this.receive(webSocket, str);
        }

        @Override                             
        public void onMessage(WebSocket webSocket, ByteString byteString) {
            GeminiLive.this.receive(webSocket, byteString.utf8());
        }

        @Override                             
        public void onFailure(WebSocket webSocket, Throwable th, Response response) {
            String str;
            if (GeminiLive.this.running) {
                GeminiLive geminiLive = GeminiLive.this;
                if (response == null) {
                    str = "Gemini Live bağlantısı kesildi · " + th.getClass().getSimpleName();
                } else {
                    str = "Gemini Live bağlantısı reddedildi · HTTP " + response.code();
                }
                geminiLive.sessionError(webSocket, str);
            }
        }

        @Override                             
        public void onClosing(WebSocket webSocket, int i, String str) {
            if (GeminiLive.this.running) {
                GeminiLive geminiLive = GeminiLive.this;
                geminiLive.sessionError(webSocket, GeminiAccess.closeMessage(i, str, geminiLive.ready));
            }
        }
    }

    private Notification notification(String str) {
        return new Notification.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("JARVIS · Gemini Live").setContentText(str).setOngoing(true).setOnlyAlertOnce(true).addAction(new Notification.Action.Builder((Icon) null, "Durdur", PendingIntent.getService(this, NOTICE, new Intent(this, (Class<?>) GeminiLive.class).setAction(STOP), 67108864)).build()).build();
    }

                                                           
    public void receive(final WebSocket webSocket, String str) {
        final JSONArray jSONArrayOptJSONArray;
        if (this.running && this.socket == webSocket) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                if (jSONObject.has("setupComplete") || jSONObject.has("setup_complete")) {
                    this.main.post(new Runnable() {                                                                         
                        @Override                      
                        public final void run() {
                            this.f$0.m31lambda$receive$2$localmertcanjarvisGeminiLive(webSocket);
                        }
                    });
                }
                JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("toolCall");
                if (jSONObjectOptJSONObject != null && (jSONArrayOptJSONArray = jSONObjectOptJSONObject.optJSONArray("functionCalls")) != null && this.running) {
                    this.tools.execute(new Runnable() {                                                                         
                        @Override                      
                        public final void run() {
                            this.f$0.m32lambda$receive$3$localmertcanjarvisGeminiLive(webSocket, jSONArrayOptJSONArray);
                        }
                    });
                }
                JSONObject jSONObjectOptJSONObject2 = jSONObject.optJSONObject("serverContent");
                if (jSONObjectOptJSONObject2 == null) {
                    return;
                }
                if (jSONObjectOptJSONObject2.optBoolean("interrupted")) {
                    this.playback.clear();
                }
                JSONObject jSONObjectOptJSONObject3 = jSONObjectOptJSONObject2.optJSONObject("inputTranscription");
                if (jSONObjectOptJSONObject3 != null && this.transcript.length() < 2048) {
                    this.transcript.append(jSONObjectOptJSONObject3.optString("text"));
                    if (sleepPhrase(this.transcript.toString())) {
                        sessionError(webSocket, "Sohbet beklemede");
                        return;
                    }
                }
                JSONObject jSONObjectOptJSONObject4 = jSONObjectOptJSONObject2.optJSONObject("modelTurn");
                JSONArray jSONArrayOptJSONArray2 = jSONObjectOptJSONObject4 == null ? null : jSONObjectOptJSONObject4.optJSONArray("parts");
                if (jSONArrayOptJSONArray2 != null) {
                    for (int i = 0; i < jSONArrayOptJSONArray2.length(); i++) {
                        JSONObject jSONObjectOptJSONObject5 = jSONArrayOptJSONArray2.getJSONObject(i).optJSONObject("inlineData");
                        if (jSONObjectOptJSONObject5 != null && jSONObjectOptJSONObject5.optString("mimeType").startsWith("audio/pcm")) {
                            byte[] bArrDecode = Base64.decode(jSONObjectOptJSONObject5.optString("data"), 0);
                            if (bArrDecode.length > 0 && !this.playback.offer(bArrDecode)) {
                                this.playback.clear();
                            }
                        }
                    }
                }
                if (jSONObjectOptJSONObject2.optBoolean("turnComplete")) {
                    LiveRepair.geminiCommand(this, this.transcript.toString());
                    this.transcript.setLength(0);
                }
            } catch (Exception | LinkageError e) {
                if (this.running) {
                    sessionError(webSocket, "Gemini Live yanıtı işlenemedi · " + e.getClass().getSimpleName());
                }
            }
        }
    }

                                                           
                                                                                                   
    public void m31lambda$receive$2$localmertcanjarvisGeminiLive(final WebSocket webSocket) {
        if (this.running && !this.ready && this.socket == webSocket) {
            this.ready = true;
            this.input = new Thread(new Runnable() {                                                                         
                @Override                      
                public final void run() throws Throwable {
                    this.f$0.m28lambda$connectAudio$4$localmertcanjarvisGeminiLive(webSocket);
                }
            }, "gemini-capture");
            this.output = new Thread(new Runnable() {                                                                         
                @Override                      
                public final void run() {
                    this.f$0.m29lambda$connectAudio$5$localmertcanjarvisGeminiLive(webSocket);
                }
            }, "gemini-playback");
            this.transcript.setLength(0);
            String str = this.openingWords;
            this.openingWords = "";
            if (!str.isEmpty() && !sleepPhrase(str)) {
                try {
                    webSocket.send(new JSONObject().put("realtimeInput", new JSONObject().put("text", str)).toString());
                } catch (JSONException unused) {
                }
            }
            this.input.start();
            this.output.start();
        }
    }

                                                           
                                                               
                                                                      
                                                        
                                                       
                                                       
                                                                                    
                                                         
                                                                                       
                                                                                             
    public void m28lambda$connectAudio$4$localmertcanjarvisGeminiLive(final WebSocket webSocket) throws Throwable {
        AudioRecord audioRecord;
        AcousticEchoCanceler acousticEchoCanceler;
        boolean enabled;
        AcousticEchoCanceler acousticEchoCanceler2 = null;
        acousticEchoCancelerCreate = null;
        AcousticEchoCanceler acousticEchoCancelerCreate = null;
        acousticEchoCanceler2 = null;
        AudioRecord audioRecord2 = null;
        try {
            audioRecord = new AudioRecord(6, 16000, 16, 2, Math.max(6400, AudioRecord.getMinBufferSize(16000, 16, 2) * 2));
            try {
                if (audioRecord.getState() != 1) {
                    throw new IllegalStateException("microphone");
                }
                if (AcousticEchoCanceler.isAvailable()) {
                    try {
                        acousticEchoCancelerCreate = AcousticEchoCanceler.create(audioRecord.getAudioSessionId());
                        if (acousticEchoCancelerCreate != null) {
                            acousticEchoCancelerCreate.setEnabled(true);
                            enabled = acousticEchoCancelerCreate.getEnabled();
                        } else {
                            enabled = false;
                        }
                    } catch (RuntimeException unused) {
                    }
                } else {
                    enabled = false;
                }
                audioRecord.startRecording();
                if (audioRecord.getRecordingState() != 3) {
                    throw new IllegalStateException("recording");
                }
                this.main.post(new Runnable() {                                                                         
                    @Override                      
                    public final void run() {
                        this.f$0.m33lambda$record$6$localmertcanjarvisGeminiLive(webSocket);
                    }
                });
                byte[] bArr = new byte[1280];
                while (this.running && this.socket == webSocket) {
                    int i = audioRecord.read(bArr, 0, 1280);
                    if (i > 0 && (enabled || !LiveRepair.geminiPlaying())) {
                        JSONObject jSONObjectPut = new JSONObject().put("audio", new JSONObject().put("mimeType", "audio/pcm;rate=16000").put("data", Base64.encodeToString(bArr, 0, i, 2)));
                        if (webSocket.queueSize() > 128000 || !webSocket.send(new JSONObject().put("realtimeInput", jSONObjectPut).toString())) {
                            sessionError(webSocket, "Gemini Live ses bağlantısı kesildi.");
                            break;
                        }
                    }
                }
                if (acousticEchoCancelerCreate != null) {
                    acousticEchoCancelerCreate.release();
                }
                try {
                    audioRecord.stop();
                } catch (RuntimeException unused2) {
                }
                audioRecord.release();
            } catch (Exception e) {
                e = e;
                audioRecord2 = audioRecord;
                acousticEchoCanceler = null;
                try {
                    if (this.running) {
                        sessionError(webSocket, "Gemini Live mikrofon hatası · " + e.getClass().getSimpleName());
                    }
                    if (acousticEchoCanceler != null) {
                        acousticEchoCanceler.release();
                    }
                    if (audioRecord2 != null) {
                        try {
                            audioRecord2.stop();
                        } catch (RuntimeException unused3) {
                        }
                        audioRecord2.release();
                    }
                } catch (Throwable th) {
                    th = th;
                    AudioRecord audioRecord3 = audioRecord2;
                    acousticEchoCanceler2 = acousticEchoCanceler;
                    audioRecord = audioRecord3;
                    if (acousticEchoCanceler2 != null) {
                        acousticEchoCanceler2.release();
                    }
                    if (audioRecord != null) {
                        try {
                            audioRecord.stop();
                        } catch (RuntimeException unused4) {
                        }
                        audioRecord.release();
                    }
                    throw th;
                }
            } catch (Throwable th2) {
                th = th2;
                if (acousticEchoCanceler2 != null) {
                    acousticEchoCanceler2.release();
                }
                if (audioRecord != null) {
                    audioRecord.stop();
                    audioRecord.release();
                }
                throw th;
            }
        } catch (Exception e2) {
            e = e2;
            acousticEchoCanceler = null;
        } catch (Throwable th3) {
            th = th3;
            audioRecord = null;
        }
    }

                                                                                                               
                    void m33lambda$record$6$localmertcanjarvisGeminiLive(WebSocket webSocket) {
        if (this.running && this.socket == webSocket) {
            state("Sohbet açık · “sessiz ol” ile beklemeye al");
        }
    }

                                                           
                                                                                           
    public void m29lambda$connectAudio$5$localmertcanjarvisGeminiLive(WebSocket webSocket) {
        AudioTrack audioTrackBuild = null;
        try {
            try {
                try {
                    audioTrackBuild = new AudioTrack.Builder().setAudioAttributes(new AudioAttributes.Builder().setUsage(1).setContentType(1).build()).setAudioFormat(new AudioFormat.Builder().setSampleRate(24000).setChannelMask(4).setEncoding(2).build()).setBufferSizeInBytes(Math.max(9600, AudioTrack.getMinBufferSize(24000, 4, 2) * 2)).setTransferMode(1).build();
                    audioTrackBuild.play();
                    while (this.running && this.socket == webSocket) {
                        byte[] bArrPoll = this.playback.poll(500L, TimeUnit.MILLISECONDS);
                        if (bArrPoll != null) {
                            LiveRepair.markGeminiPlayback(bArrPoll.length);
                            audioTrackBuild.write(bArrPoll, 0, bArrPoll.length);
                        }
                    }
                    if (audioTrackBuild == null) {
                        return;
                    }
                } catch (InterruptedException unused) {
                    Thread.currentThread().interrupt();
                    if (audioTrackBuild == null) {
                        return;
                    }
                }
            } catch (RuntimeException e) {
                if (this.running) {
                    sessionError(webSocket, "Gemini Live ses çıkışı açılamadı · " + e.getClass().getSimpleName());
                }
                if (audioTrackBuild == null) {
                    return;
                }
            }
            audioTrackBuild.release();
        } catch (Throwable th) {
            if (audioTrackBuild != null) {
                audioTrackBuild.release();
            }
            throw th;
        }
    }

                                                           
                                                                                               
    public void m32lambda$receive$3$localmertcanjarvisGeminiLive(WebSocket webSocket, JSONArray jSONArray) {
        String strDispatchDeviceTool;
        try {
            JSONArray jSONArray2 = new JSONArray();
            for (int i = 0; this.running && this.socket == webSocket && i < jSONArray.length(); i++) {
                JSONObject jSONObject = jSONArray.getJSONObject(i);
                String string = jSONObject.getString("name");
                if ("sleep_live".equals(string)) {
                    sessionError(webSocket, "Sohbet beklemede");
                    return;
                }
                try {
                    strDispatchDeviceTool = GeminiAccess.dispatchDeviceTool(this, string, jSONObject);
                    if (strDispatchDeviceTool == null) {
                        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("args");
                        if ("research".equals(string) && jSONObjectOptJSONObject != null) {
                            strDispatchDeviceTool = Cloud.research(jSONObjectOptJSONObject.optString("query"), Cloud.key).text;
                        } else if ("music".equals(string) && jSONObjectOptJSONObject != null) {
                            strDispatchDeviceTool = Actions.run(this, jSONObjectOptJSONObject.optString("action"), jSONObjectOptJSONObject.optString("query"));
                        } else if ("news".equals(string) || "rates".equals(string)) {
                            strDispatchDeviceTool = Actions.run(this, string);
                        } else {
                            strDispatchDeviceTool = "Komut desteklenmiyor.";
                        }
                    }
                } catch (Exception e) {
                    strDispatchDeviceTool = "Komut tamamlanamadı · " + e.getClass().getSimpleName();
                }
                jSONArray2.put(new JSONObject().put("id", jSONObject.getString("id")).put("name", string).put("response", new JSONObject().put("result", strDispatchDeviceTool)));
            }
            if (this.running && this.socket == webSocket) {
                webSocket.send(new JSONObject().put("toolResponse", new JSONObject().put("functionResponses", jSONArray2)).toString());
            }
        } catch (Exception unused) {
            if (this.running) {
                GeminiAccess.report(this, "Gemini Live komut yanıtı gönderilemedi.");
            }
        }
    }

    static boolean sleepPhrase(String str) {
        String strTrim = Normalizer.normalize(str.toLowerCase(Locale.forLanguageTag("tr-TR")), Normalizer.Form.NFD).replaceAll("\\p{M}+", "").replace((char) 305, 'i').replaceAll("[^a-z ]", " ").replaceAll("\\s+", " ").trim();
        return strTrim.equals("sessiz ol") || strTrim.equals("live modu bitir") || strTrim.equals("live modunu bitir") || strTrim.equals("canli modu bitir") || strTrim.equals("canli yayini bitir") || strTrim.equals("sohbeti bitir");
    }

                                                           
    public void fail(final String str) {
        this.main.post(new Runnable() {                                                                         
            @Override                      
            public final void run() {
                this.f$0.m30lambda$fail$7$localmertcanjarvisGeminiLive(str);
            }
        });
    }

                                                                                                             
                    void m30lambda$fail$7$localmertcanjarvisGeminiLive(String str) {
        GeminiAccess.report(this, str);
        stopSelf();
    }

    @Override                       
    public void onDestroy() {
        this.running = false;
        active = false;
        closeWakeRecognizer();
        GeminiAccess.reportStatus("Eller serbest kapalı");
        LiveRepair.clearGeminiPlayback();
        this.main.removeCallbacksAndMessages(null);
        if (this.socket != null) {
            this.socket.cancel();
        }
        Thread thread = this.input;
        if (thread != null) {
            thread.interrupt();
        }
        Thread thread2 = this.output;
        if (thread2 != null) {
            thread2.interrupt();
        }
        this.tools.shutdownNow();
        this.playback.clear();
        stopForeground(1);
        super.onDestroy();
    }
}
