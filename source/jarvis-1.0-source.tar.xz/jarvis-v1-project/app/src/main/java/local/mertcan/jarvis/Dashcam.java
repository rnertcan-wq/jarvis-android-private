package local.mertcan.jarvis;

import android.R;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.Size;
import android.view.Surface;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Set;

                                         
public final class Dashcam extends Service {
    private static final long SEGMENT_MS = 300000;
    static final String STATUS = "local.mertcan.jarvis.RECORDING_STATUS";
    static final String STOP = "local.mertcan.jarvis.STOP_RECORDING";
    private boolean closing;
    private int displayDegrees;
    private boolean dual;
    private boolean frontOnly;
    private boolean frontPreviewOnly;
    private int generation;
    private Handler handler;
    private boolean sound;
    private volatile boolean stopRequested;
    private HandlerThread worker;
    private final List<Track> tracks = new ArrayList();

    static List<String> cameras(CameraManager cameraManager, boolean z) throws CameraAccessException {
        return cameras(cameraManager, z, false);
    }

    private static List<String> cameras(CameraManager cameraManager, boolean z, boolean z2) throws CameraAccessException {
        if (z && Build.VERSION.SDK_INT >= 30) {
            Iterator<Set<String>> it = cameraManager.getConcurrentCameraIds().iterator();
            while (it.hasNext()) {
                String str = null;
                String str2 = null;
                for (String str3 : it.next()) {
                    Integer num = (Integer) cameraManager.getCameraCharacteristics(str3).get(CameraCharacteristics.LENS_FACING);
                    if (Objects.equals(num, 0)) {
                        str = str3;
                    }
                    if (Objects.equals(num, 1)) {
                        str2 = str3;
                    }
                }
                if (str != null && str2 != null) {
                    return Arrays.asList(str2, str);
                }
            }
            return Collections.emptyList();
        }
        if (z) {
            return Collections.emptyList();
        }
        for (String str4 : cameraManager.getCameraIdList()) {
            if (Objects.equals(cameraManager.getCameraCharacteristics(str4).get(CameraCharacteristics.LENS_FACING), Integer.valueOf(!z2 ? 1 : 0))) {
                return Collections.singletonList(str4);
            }
        }
        return Collections.emptyList();
    }

    @Override                       
    public void onCreate() {
        super.onCreate();
        this.worker = new HandlerThread("dashcam");
        this.worker.start();
        this.handler = new Handler(this.worker.getLooper());
    }

    @Override                       
    public IBinder onBind(Intent intent) {
        return null;
    }

                                                                                                                    
                    void m2lambda$onStartCommand$0$localmertcanjarvisDashcam() {
        end("Kayıt durduruldu.");
    }

    @Override                       
    public int onStartCommand(Intent intent, int i, int i2) {
        if (intent != null && STOP.equals(intent.getAction())) {
            this.stopRequested = true;
            this.handler.post(new Runnable() {                                                                      
                @Override                      
                public final void run() {
                    this.f$0.m2lambda$onStartCommand$0$localmertcanjarvisDashcam();
                }
            });
            return 2;
        }
        if (intent == null || this.generation != 0 || this.stopRequested) {
            return 2;
        }
        this.sound = intent.getBooleanExtra("sound", false);
        this.dual = intent.getBooleanExtra("dual", false);
        this.frontOnly = intent.getBooleanExtra("front", false);
        this.frontPreviewOnly = intent.getBooleanExtra("frontPreviewOnly", false);
        this.displayDegrees = intent.getIntExtra("displayDegrees", 0);
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(79, notification("Kameralar hazırlanıyor…"), DriveCamera.foregroundTypes(this, 64 | (this.sound ? 128 : 0)));
            } else {
                startForeground(79, notification("Kameralar hazırlanıyor…"));
            }
            this.generation = 1;
            DriveCamera.register(this, this.sound);
            this.handler.post(new Dashcam$$ExternalSyntheticLambda1(this));
            return 2;
        } catch (RuntimeException e) {
            report("Kayıt başlatılamadı; uygulama açıkken tekrar dene.");
            stopSelf();
            return 2;
        }
    }

                                                           
    public Notification notification(String str) {
        ((NotificationManager) getSystemService(NotificationManager.class)).createNotificationChannel(new NotificationChannel("dashcam", "Sürüş kaydı", 2));
        PendingIntent service = PendingIntent.getService(this, 79, new Intent(this, (Class<?>) Dashcam.class).setAction(STOP), 67108864);
        return new Notification.Builder(this, "dashcam").setSmallIcon(android.R.drawable.ic_menu_camera).setContentTitle("Jarvis sürüş kaydı").setContentText(str).setContentIntent(PendingIntent.getActivity(this, 80, new Intent(this, (Class<?>) Main.class), 67108864)).setOngoing(true).addAction(new Notification.Action.Builder((Icon) null, "Durdur", service).build()).build();
    }

                                                           
    public void report(String str) {
        DriveDashboard.cameraStatus(str);
        sendBroadcast(new Intent(STATUS).setPackage(getPackageName()).putExtra("text", str));
    }

                                                           
    public void startSegment() {
        if (this.closing || this.stopRequested) {
            return;
        }
        CameraManager cameraManager = (CameraManager) getSystemService(CameraManager.class);
        final int i = this.generation;
        try {
            Retention.purge(this);
            List<String> listCameras = cameras(cameraManager, this.dual, this.frontOnly);
            if (listCameras.isEmpty()) {
                end(this.dual ? "Bu telefon çift kamerayı aynı anda açmıyor. Tek kamera seç." : (this.frontOnly ? "Ön" : "Arka") + " kamera bulunamadı.");
                return;
            }
            long jCurrentTimeMillis = System.currentTimeMillis();
            int i2 = 0;
            while (i2 < listCameras.size()) {
                boolean isFront = this.dual ? i2 == 1 : this.frontOnly;
                boolean previewOnly = this.frontPreviewOnly && this.dual && isFront;
                String label = isFront ? "on" : "arka";
                this.tracks.add(new Track(listCameras.get(i2), label, jCurrentTimeMillis,
                        this.sound && !isFront, previewOnly));
                i2++;
            }
            for (final Track track : this.tracks) {
                track.prepare(cameraManager);
                cameraManager.openCamera(track.id, new CameraDevice.StateCallback() {                                              
                    @Override                                                       
                    public void onOpened(CameraDevice cameraDevice) {
                        if (i != Dashcam.this.generation || Dashcam.this.closing || Dashcam.this.stopRequested) {
                            cameraDevice.close();
                            return;
                        }
                        track.device = cameraDevice;
                        Iterator it = Dashcam.this.tracks.iterator();
                        while (it.hasNext()) {
                            if (((Track) it.next()).device == null) {
                                return;
                            }
                        }
                        Iterator it2 = Dashcam.this.tracks.iterator();
                        while (it2.hasNext()) {
                            Dashcam.this.configure((Track) it2.next(), i);
                        }
                    }

                    @Override                                                       
                    public void onDisconnected(CameraDevice cameraDevice) {
                        cameraDevice.close();
                        if (i != Dashcam.this.generation || Dashcam.this.closing) {
                            return;
                        }
                        Dashcam.this.end("Kamera bağlantısı kesildi.");
                    }

                    @Override                                                       
                    public void onError(CameraDevice cameraDevice, int i3) {
                        cameraDevice.close();
                        if (i != Dashcam.this.generation || Dashcam.this.closing) {
                            return;
                        }
                        Dashcam.this.end("Kamera açılamadı (" + i3 + ").");
                    }
                }, this.handler);
            }
            this.handler.postDelayed(new Runnable() {                                                                      
                @Override                      
                public final void run() {
                    this.f$0.m3lambda$startSegment$1$localmertcanjarvisDashcam(i);
                }
            }, 12000L);
        } catch (Exception e) {
            end("Kamera veya mikrofon hazırlanamadı.");
        }
    }

                                                                                                                  
                    void m3lambda$startSegment$1$localmertcanjarvisDashcam(int i) {
        if (i != this.generation || this.closing) {
            return;
        }
        Iterator<Track> it = this.tracks.iterator();
        while (it.hasNext()) {
            if (!it.next().started) {
                end("Kamera zamanında açılamadı.");
                return;
            }
        }
    }

                                                           
    public void configure(Track track, int i) {
        if (this.closing || this.stopRequested || i != this.generation) {
            return;
        }
        try {
            if (track.previewOnly) {
                CaptureRequest.Builder previewRequest = track.device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                DriveDashboard.createPreviewSession(track.device, previewRequest,
                        new AnonymousClass2(i, track, previewRequest), this.handler);
                return;
            }
            Surface surface = track.recorder.getSurface();
            CaptureRequest.Builder builderCreateCaptureRequest = track.device.createCaptureRequest(CameraDevice.TEMPLATE_RECORD);
            builderCreateCaptureRequest.addTarget(surface);
            DriveDashboard.createSession(track.device, surface, builderCreateCaptureRequest, new AnonymousClass2(i, track, builderCreateCaptureRequest), this.handler);
        } catch (Exception e) {
            end("Kamera oturumu kurulamadı.");
        }
    }

                                                                                             
    class AnonymousClass2 extends CameraCaptureSession.StateCallback {
        final                 int val$g;
        final                 CaptureRequest.Builder val$req;
        final                 Track val$t;

        AnonymousClass2(int i, Track track, CaptureRequest.Builder builder) {
            this.val$g = i;
            this.val$t = track;
            this.val$req = builder;
        }

        @Override                                                               
        public void onConfigured(CameraCaptureSession cameraCaptureSession) {
            String str;
            String str2;
            if (Dashcam.this.closing || Dashcam.this.stopRequested || this.val$g != Dashcam.this.generation) {
                cameraCaptureSession.close();
                return;
            }
            this.val$t.session = cameraCaptureSession;
            try {
                cameraCaptureSession.setRepeatingRequest(this.val$req.build(), null, Dashcam.this.handler);
                Iterator it = Dashcam.this.tracks.iterator();
                while (it.hasNext()) {
                    if (((Track) it.next()).session == null) {
                        return;
                    }
                }
                for (Track track : Dashcam.this.tracks) {
                    if (track.recorder != null) track.recorder.start();
                    track.started = true;
                }
                StringBuilder sb = new StringBuilder();
                if (Dashcam.this.dual && Dashcam.this.frontPreviewOnly) {
                    str = "Arka kamera kayıtta · Ön kamera yalnızca yerel sürücü kontrolünde";
                } else if (Dashcam.this.dual) {
                    str = "Ön ve arka kamera";
                } else {
                    str = Dashcam.this.frontOnly ? "Ön kamera" : "Arka kamera";
                }
                StringBuilder sbAppend = sb.append(str);
                if (!(Dashcam.this.dual && Dashcam.this.frontPreviewOnly)) sbAppend.append(" kayıtta");
                if (Dashcam.this.sound && Dashcam.this.dual) {
                    str2 = "; ses arka kamera dosyasında.";
                } else {
                    str2 = Dashcam.this.sound ? " (sesli)." : ".";
                }
                String string = sbAppend.append(str2).toString();
                ((NotificationManager) Dashcam.this.getSystemService(NotificationManager.class)).notify(79, Dashcam.this.notification(string));
                Dashcam.this.report(string);
                Handler handler = Dashcam.this.handler;
                final int i = this.val$g;
                handler.postDelayed(new Runnable() {                                                                        
                    @Override                      
                    public final void run() {
                        this.f$0.m4lambda$onConfigured$0$localmertcanjarvisDashcam$2(i);
                    }
                }, Dashcam.SEGMENT_MS);
            } catch (Exception e) {
                Dashcam.this.end("Kayıt açılamadı; tek kamera veya sessiz kayıt dene.");
            }
        }

                                                                                                                        
                        void m4lambda$onConfigured$0$localmertcanjarvisDashcam$2(int i) {
            Dashcam.this.rotate(i);
        }

        @Override                                                               
        public void onConfigureFailed(CameraCaptureSession cameraCaptureSession) {
            cameraCaptureSession.close();
            if (Dashcam.this.closing || this.val$g != Dashcam.this.generation) {
                return;
            }
            Dashcam.this.end("Bu kamera kombinasyonunda video kaydı açılamadı.");
        }
    }

                                                           
    public void rotate(int i) {
        if (this.closing || this.stopRequested || i != this.generation) {
            return;
        }
        this.generation++;
        release();
        this.handler.postDelayed(new Dashcam$$ExternalSyntheticLambda1(this), 700L);
    }

                                                           
    public void end(String str) {
        if (this.closing) {
            return;
        }
        this.closing = true;
        this.generation++;
        this.handler.removeCallbacksAndMessages(null);
        release();
        report(str);
        stopForeground(1);
        stopSelf();
    }

    private void release() {
        Iterator<Track> it = this.tracks.iterator();
        while (it.hasNext()) {
            it.next().close();
        }
        this.tracks.clear();
    }

    @Override                       
    public void onDestroy() {
        DriveCamera.unregister(this);
        this.stopRequested = true;
        this.handler.post(new Runnable() {                                                                      
            @Override                      
            public final void run() {
                this.f$0.m1lambda$onDestroy$2$localmertcanjarvisDashcam();
            }
        });
        super.onDestroy();
    }

                                                                                                               
                    void m1lambda$onDestroy$2$localmertcanjarvisDashcam() {
        release();
        this.worker.quitSafely();
    }

                                                           
    final class Track {
        CameraDevice device;
        final File finalFile;
        final String id;
        final boolean mic;
        final boolean previewOnly;
        final File partial;
        MediaRecorder recorder;
        CameraCaptureSession session;
        boolean started;

        Track(String str, String str2, long j, boolean z, boolean previewOnly) {
            this.id = str;
            this.mic = z;
            this.previewOnly = previewOnly;
            if (previewOnly) {
                this.partial = null;
                this.finalFile = null;
                return;
            }
            File fileDirectory = Retention.directory(Dashcam.this);
            this.partial = new File(fileDirectory, j + "-" + str2 + ".partial");
            this.finalFile = new File(fileDirectory, j + "-" + str2 + ".mp4");
        }

        void prepare(CameraManager cameraManager) throws Exception {
            if (this.previewOnly) return;
            if (Retention.directory(Dashcam.this).getUsableSpace() < 262144000) {
                throw new IOException("Storage low");
            }
            CameraCharacteristics cameraCharacteristics = cameraManager.getCameraCharacteristics(this.id);
            StreamConfigurationMap streamConfigurationMap = (StreamConfigurationMap) cameraCharacteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Size size = null;
            Size[] outputSizes = streamConfigurationMap == null ? null : streamConfigurationMap.getOutputSizes(MediaRecorder.class);
            if (outputSizes != null) {
                for (Size size2 : outputSizes) {
                    int width = size2.getWidth() * size2.getHeight();
                    if (width <= 921600 && width >= 76800 && (size == null || width > size.getWidth() * size.getHeight())) {
                        size = size2;
                    }
                }
            }
            if (size == null) {
                throw new IOException("Video size unavailable");
            }
            this.recorder = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(Dashcam.this) : new MediaRecorder();
            if (this.mic) {
                this.recorder.setAudioSource(5);
            }
            this.recorder.setVideoSource(2);
            this.recorder.setOutputFormat(2);
            this.recorder.setVideoEncoder(2);
            this.recorder.setVideoSize(size.getWidth(), size.getHeight());
            this.recorder.setVideoFrameRate(30);
            this.recorder.setVideoEncodingBitRate(2200000);
            Integer num = (Integer) cameraCharacteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
            this.recorder.setOrientationHint((((num != null ? num.intValue() : 0) + (Objects.equals(cameraCharacteristics.get(CameraCharacteristics.LENS_FACING), 0) ? Dashcam.this.displayDegrees : -Dashcam.this.displayDegrees)) + 360) % 360);
            if (this.mic) {
                this.recorder.setAudioEncoder(3);
                this.recorder.setAudioEncodingBitRate(96000);
            }
            this.recorder.setOutputFile(this.partial.getAbsolutePath());
            this.recorder.setOnErrorListener(new MediaRecorder.OnErrorListener() {                                                                            
                @Override                                               
                public final void onError(MediaRecorder mediaRecorder, int i, int i2) {
                    this.f$0.m5lambda$prepare$0$localmertcanjarvisDashcam$Track(mediaRecorder, i, i2);
                }
            });
            this.recorder.prepare();
        }

                                                                                                                       
                        void m5lambda$prepare$0$localmertcanjarvisDashcam$Track(MediaRecorder mediaRecorder, int i, int i2) {
            if (this.recorder != mediaRecorder || Dashcam.this.closing) {
                return;
            }
            Dashcam.this.end("Kayıt cihazı hata verdi.");
        }

        void close() {
            if (this.session != null) {
                try {
                    this.session.stopRepeating();
                } catch (Exception e) {
                }
                this.session.close();
            }
            boolean z = false;
            if (this.recorder != null) {
                if (this.started) {
                    try {
                        this.recorder.stop();
                        z = true;
                    } catch (RuntimeException e2) {
                    }
                }
                this.recorder.release();
                this.recorder = null;
            }
            if (this.device != null) {
                this.device.close();
            }
            if (this.previewOnly) return;
            if (z) {
                if (this.partial.renameTo(this.finalFile)) {
                    this.finalFile.setLastModified(System.currentTimeMillis());
                    return;
                }
                return;
            }
            if (this.partial != null) this.partial.delete();
        }
    }
}
