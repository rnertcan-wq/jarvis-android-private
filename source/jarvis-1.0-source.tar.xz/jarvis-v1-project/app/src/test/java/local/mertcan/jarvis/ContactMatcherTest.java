package local.mertcan.jarvis;

import org.junit.Test;
import static org.junit.Assert.*;

public class ContactMatcherTest {
    @Test public void possessiveAccusativeFindsSavedAnnem() {
        assertTrue(ContactMatcher.matchesForTest("annemi", "Annem"));
    }

    @Test public void possessiveFindsSavedAnne() {
        assertTrue(ContactMatcher.matchesForTest("annem", "Anne"));
    }

    @Test public void inflectedSiblingNameMatches() {
        assertTrue(ContactMatcher.matchesForTest("kardesimi", "Kardeşim"));
    }

    @Test public void turkishDottedAndDotlessIAreNormalized() {
        assertEquals("istanbul", ContactMatcher.normalize("İSTANBUL"));
        assertEquals("izmir", ContactMatcher.normalize("İzmir"));
    }

    @Test public void unrelatedNamesDoNotMatch() {
        assertFalse(ContactMatcher.matchesForTest("annemi", "Mehmet Yılmaz"));
    }
}
