# JARVIS AI 1.0 — recovered Android project

This project is a source reconstruction and enhancement of the user-provided `local.mertcan.jarvis` v0.9.9 APK. It is intentionally built as a side-by-side test application (`local.mertcan.jarvis.next`) so the existing v0.9.9 installation is not overwritten.

## Build

Requirements: JDK 17, Android SDK Platform 35, Android Build Tools 35.0.0, Gradle 8.11.1.

```bash
gradle --no-daemon testDebugUnitTest assembleDebug
```

The debug APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

## Important configuration

- No EVREN API key is included in this source package. Enter the key inside JARVIS settings after installation.
- No Gemini API key is included. Configure it in the app if Gemini Live is selected.
- Google Maps turn-by-turn navigation is opened through the installed Google Maps app. The in-app driving canvas keeps its map view and the small camera preview; the in-app map tiles are OpenStreetMap. A Google Maps SDK key and billing-enabled Cloud project are required for a fully embedded Google map, so no fake key is bundled.
- Android requires explicit runtime permissions for microphone, contacts, phone calls, camera, location and notifications. Screen-off wake listening is subject to Android/OEM microphone and battery restrictions; it is not guaranteed on every device.
- The driver-facing camera is preview-only in the driving dashboard. It is not written to the dashcam recording and is not uploaded to EVREN. It requires explicit opt-in and concurrent front/rear camera support from the phone.
- Calling a contact requires a spoken confirmation. If multiple matching contacts or numbers are found, JARVIS asks for a spoken first/second/third selection before asking for final confirmation.

## Security

The original APK contained a bootstrap credential asset. It has been deliberately excluded from this source project. Rotate that credential in the EVREN dashboard if it was active, then enter the replacement key in the app.

## Current validation

Unit tests cover Turkish contact-name normalization and inflected names (`annemi` -> `Annem`). A real Android build and device test must still pass before treating this as a release. The first APK is a side-by-side test build, not an in-place update of v0.9.9.
